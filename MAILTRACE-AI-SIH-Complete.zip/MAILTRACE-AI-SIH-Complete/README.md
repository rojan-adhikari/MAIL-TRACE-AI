# MAILTRACE AI

**Evidence-driven Email Threat Detection & Forensic Intelligence**

Offline-first national-hackathon prototype aligned to SIH26106: **AI-Powered Email Threat Detection, GeoLocation and Forensic Intelligence Platform**.

MAILTRACE AI is an email investigation engine, not only a spam classifier. It answers:

1. Is this email suspicious?
2. Why is it suspicious?
3. How did it travel through mail infrastructure?
4. What infrastructure and previous cases are connected to it?
5. How reliable is each conclusion?

## Important attribution rule

The platform reports **observed network infrastructure**, **probable infrastructure location**, **device/mail-client clues**, **evidence confidence** and **attribution confidence**. It does not claim that an IP proves a person's physical location, identity or device.

## What is implemented

- Paste/write email analysis and five one-click safe synthetic scenarios.
- Read-only Gmail INBOX synchronization and near-real-time alert monitoring.
- MIME/header parsing, attachment hashing without execution, and malformed-input handling.
- SPF, DKIM, DMARC and ARC result extraction from receiver-generated headers.
- From, Reply-To, Return-Path, Message-ID and DKIM-domain consistency checks.
- Trusted-boundary relay reconstruction with timestamps and green/yellow/red confidence.
- Public/private/test IP classification, probable infrastructure IP and explicit uncertainty.
- On-demand IP geolocation/ASN/provider and domain DNS/RDAP enrichment.
- Lookalike-domain engine using edit distance, Jaro-Winkler, brand tokens and IDN/Punycode checks.
- URL extraction, anchor/destination mismatch, IP URLs, shorteners, redirect parameters and obfuscation indicators.
- BEC categories for payment, executive, vendor, credential, payroll and sensitive-data requests.
- Runtime TF-IDF logistic-regression model plus evidence-aware hybrid scoring.
- Separate threat score and evidence confidence.
- Safe adversarial-evasion stability checks.
- Interactive infrastructure graph and confidence-radius geolocation map.
- SQLite case management, notes, analyst decisions and audit events.
- Weighted campaign correlation across IP, ASN, provider, domain, URL and attachment hash.
- SHA-256 tamper-evident evidence ledger and chain verification.
- Dependency-free multi-page PDF forensic report.
- Runtime benchmark with actual calculated metrics and explicit dataset limitations.
- Privacy mode, local settings, no frontend API keys and graceful offline fallbacks.

## Architecture

```mermaid
flowchart TD
    UI[Analyst Web Interface] --> API[Local API Gateway]
    API --> ORCH[Investigation Orchestrator]
    ORCH --> FORENSICS[Header + MIME Forensics]
    ORCH --> DETECT[BEC + URL + Domain + ML]
    ORCH --> INTEL[Optional Public Intelligence]
    FORENSICS --> FUSION[Evidence Fusion]
    DETECT --> FUSION
    INTEL --> FUSION
    FUSION --> GRAPH[Graph + Campaign Correlation]
    GRAPH --> STORE[(SQLite Cases + Ledger)]
    STORE --> REPORT[PDF Forensic Report]
```

The portable MVP uses Python's standard library, SQLite and a local web frontend so it runs without downloading packages. A production deployment can replace the gateway with FastAPI, SQLite with PostgreSQL, and the in-process graph with Neo4j while preserving the documented API/domain boundaries.

## Run on macOS

1. Extract the ZIP.
2. Right-click `START-MAILTRACE.command` and choose **Open**.
3. Keep Terminal open.
4. The browser opens <http://127.0.0.1:8788>.

If Gmail shows a certificate error, open **Applications → Python 3.x → Install Certificates.command**, wait for `update complete`, and restart MAILTRACE.

## Run on Windows

Extract the ZIP and double-click `start-windows.bat`.

## Run manually

```bash
python3 server.py
```

## Judge demonstration

Click **RUN COMPLETE SIH DEMO** on the Dashboard or Investigation page. MAILTRACE loads the safe synthetic CEO-impersonation scenario, runs the complete pipeline, saves a case, creates an evidence ledger and enables PDF export.

After the verdict appears, the visible result shortcuts open **Sender + Device**, **Why This Verdict**, **Relay Path**, **IP + Location** and **Threat Graph**. The full evidence workspace is also available immediately below the verdict.

On a narrow, zoomed or split-screen browser, click the persistent **☰ MODULES** button to open Dashboard, Gmail Live, Cases, Threat Graph, Campaigns, Threat Intelligence, Reports, Model Evaluation and Settings. The menu remains available while scrolling.

Other scenarios are available in **Investigate → Demonstration scenario**:

1. Legitimate corporate email
2. Lookalike-domain phishing
3. CEO impersonation BEC
4. Invoice/payment diversion
5. Credential harvesting

All demo IPs, organizations, ASNs, locations and messages are synthetic fixtures and are labelled as such.

## Gmail connection

1. Enable Google two-step verification.
2. Create a Google App Password named `MAILTRACE AI`.
3. Open **Gmail Live**.
4. Enter the Gmail address and generated App Password.

Never use or share the normal Gmail password. Credentials remain only in process memory and are cleared on disconnect or shutdown. Gmail access is read-only.

## Data and ML approach

`data/dataset.json` contains separate train, validation and test splits. The dataset is intentionally small, curated and synthetic. The runtime model trains on the train split only and reports metrics on the test split. The interface explicitly warns that strong small-dataset metrics are not production accuracy claims.

The final verdict is evidence-driven. The language model contributes one evidence category and cannot invent authentication, routing, IP, URL or domain evidence.

## External intelligence

Core investigation works offline. Public IP/DNS/RDAP lookups happen only after an analyst action. Missing services display **NOT CONFIGURED** or **External enrichment unavailable — local analysis continued**. API keys are read only from environment variables described in `.env.example`.

## Privacy and security

- Binds only to `127.0.0.1`.
- No hardcoded credentials or API keys.
- Privacy mode masks email addresses before case storage.
- Message bodies are not written into case analysis JSON.
- Attachments are hashed and never executed.
- External lookup receives only the selected IP/domain.
- Evidence is normalized, hashed and chained.
- Analyst decisions and notes are auditable.
- The platform is defensive and does not scan or exploit infrastructure.

## Reports

Every saved case can export a PDF with executive summary, metadata, verdict, confidence, authentication, route, IP/geolocation, domain/URL/BEC analysis, graph edges, campaign correlation, indicators, evidence hashes, chain of custody, conclusion and limitations.

## API documentation

See [`docs/api-documentation.md`](docs/api-documentation.md). All frontend buttons call implemented endpoints.

## Tests

```bash
python3 -m unittest discover -s tests -v
node --check web/app.js
```

Tests cover route trust, identity mismatch, lookalike domains, BEC classification, threat/confidence separation, ledger verification, campaign correlation, PDF generation, private-IP rejection, runtime dataset evaluation and frontend feature discoverability.

## Docker

```bash
docker compose up --build
```

Open <http://127.0.0.1:8788>. Gmail App Passwords are entered only at runtime and are not stored in the image.

## Documentation

- [`docs/architecture.md`](docs/architecture.md)
- [`docs/research.md`](docs/research.md)
- [`docs/threat-model.md`](docs/threat-model.md)
- [`docs/dataset.md`](docs/dataset.md)
- [`docs/model-evaluation.md`](docs/model-evaluation.md)
- [`docs/api-documentation.md`](docs/api-documentation.md)
- [`docs/demo-script.md`](docs/demo-script.md)
- [`docs/limitations.md`](docs/limitations.md)

## Future production scope

- FastAPI/JWT/RBAC gateway and PostgreSQL/Neo4j deployment.
- Organization-specific trusted receiving boundaries and protected identities.
- Cryptographic DKIM verification and authorized DNS-based SPF/DMARC evaluation.
- Licensed offline GeoIP and commercial reputation sources.
- Sandboxed attachment detonation in an isolated analysis environment.
- Larger independently curated datasets and cross-organization evaluation.
- Permissioned-ledger anchoring of periodic evidence-chain roots.

This repository is a technically honest, fully runnable prototype—not a claim of production deployment, government partnership, law-enforcement usage or guaranteed attacker attribution.
