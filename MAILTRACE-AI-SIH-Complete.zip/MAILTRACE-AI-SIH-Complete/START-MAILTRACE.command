#!/bin/bash
set -u
cd "$(dirname "$0")"
clear
echo "MAILTRACE AI — SIH Forensic Intelligence"
echo "Starting local offline-first service..."
echo
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required. Install it from https://www.python.org/downloads/macos/"
  read -r -p "Press Return to close."
  exit 1
fi
python3 server.py
status=$?
echo
echo "MAILTRACE stopped (exit code $status)."
read -r -p "Press Return to close."
exit "$status"
