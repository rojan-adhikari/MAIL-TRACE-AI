# API Documentation

The portable API is served only on `http://127.0.0.1:8788` by default.

## Investigation

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Local health and version |
| GET | `/api/demos` | Five safe synthetic scenario descriptors |
| POST | `/api/investigate` | Analyze pasted email or demo; optionally save a case |
| GET | `/api/benchmark` | Recalculate held-out runtime metrics |

`POST /api/investigate` body:

```json
{
  "demoId": "demo-ceo-bec",
  "raw": "",
  "saveCase": true,
  "privacyMode": false,
  "analyst": "Rozan Adhikari"
}
```

Use either `demoId` or `raw`. The response returns structured analysis and, when requested, the saved case.

## Cases and reports

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/dashboard` | Case statistics and recent investigations |
| GET | `/api/cases` | List cases |
| GET | `/api/case?id=CASE-ID` | Complete case, notes, decisions and ledger |
| POST | `/api/case/note` | Add analyst note |
| POST | `/api/case/decision` | Record human decision |
| GET | `/api/campaigns` | Correlated campaigns |
| GET | `/api/report?caseId=CASE-ID` | Download forensic PDF |

Allowed decisions: `CONFIRM THREAT`, `MARK FALSE POSITIVE`, `ESCALATE`, `ADD TO CAMPAIGN`, `DISMISS`, `CLOSE CASE`.

## Intelligence

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/integrations` | Connected/not-configured status |
| POST | `/api/enrich/ip` | On-demand public-IP geolocation and ASN |
| POST | `/api/enrich/domain` | On-demand DNS A/AAAA and public RDAP |

Private, loopback, reserved and synthetic-demo IPs are rejected by the live lookup endpoint.

## Gmail

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/gmail/connect` | Connect read-only Gmail using an App Password |
| POST | `/api/gmail/disconnect` | Clear credentials and in-memory messages |
| GET | `/api/gmail/status` | Sync/monitor status |
| GET | `/api/gmail/messages` | Paginated analyzed message summaries |
| GET | `/api/gmail/message?uid=UID` | Detailed analysis |
| GET | `/api/gmail/alerts` | Suspicious-message alerts |
| POST | `/api/gmail/save-case` | Preserve selected message analysis as a case |

## Errors

Errors are JSON objects with `error`. External failure can include `fallback: Local analysis continued`. Missing integrations never return simulated live data.
