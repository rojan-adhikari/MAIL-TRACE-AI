# MAILTRACE AI Architecture

## System architecture

```mermaid
flowchart TD
    UI[Analyst Interface] --> GW[Local API Gateway]
    GW --> ORCH[Investigation Orchestrator]
    ORCH --> PARSE[Email and MIME Parser]
    ORCH --> AUTH[Header and Authentication]
    ORCH --> DETECT[BEC, URL, Domain and ML]
    ORCH --> INTEL[Optional IP, DNS and RDAP]
    PARSE --> FUSION[Evidence Fusion Engine]
    AUTH --> FUSION
    DETECT --> FUSION
    INTEL --> FUSION
    FUSION --> GRAPH[Graph and Campaign Correlator]
    GRAPH --> DB[(SQLite Case Store)]
    DB --> LEDGER[SHA-256 Evidence Ledger]
    DB --> PDF[Forensic PDF]
```

## Threat-detection flow

```mermaid
flowchart TD
    INPUT[Headers and message] --> FEATURES[Deterministic features]
    FEATURES --> RULES[Authentication, identity, URL and BEC rules]
    FEATURES --> ML[Runtime TF-IDF model]
    RULES --> EVIDENCE[Structured evidence]
    ML --> EVIDENCE
    EVIDENCE --> SCORE[Threat score]
    EVIDENCE --> CONF[Evidence confidence]
    SCORE --> VERDICT[Confidence-aware verdict]
    CONF --> VERDICT
```

## Forensic investigation flow

```mermaid
sequenceDiagram
    participant A as Analyst
    participant O as Orchestrator
    participant F as Forensics
    participant I as Intelligence
    participant C as Case Store
    A->>O: Submit authorized email
    O->>F: Parse headers, route, URLs and MIME
    F-->>O: Structured evidence with confidence
    O->>I: Optional IP/domain enrichment
    I-->>O: Infrastructure observations or unavailable
    O-->>A: Threat score and evidence confidence
    A->>C: Save case
    C->>C: Hash and chain evidence
    C-->>A: Case ID and report
```

## Threat graph

```mermaid
flowchart TD
    EMAIL[Email] -->|SENT_FROM| SENDER[Sender]
    SENDER --> DOMAIN[Domain]
    DOMAIN -->|OBSERVED_ON| IP[IP]
    IP -->|HOSTED_ON| ASN[ASN]
    ASN --> PROVIDER[Provider]
    EMAIL --> URL[URL]
    EMAIL --> ATTACH[Attachment hash]
    EMAIL -->|SEEN_IN_CAMPAIGN| CAMPAIGN[Campaign]
```

## Data flow and trust boundaries

```mermaid
flowchart LR
    subgraph Local[Local trusted boundary]
      Browser[Browser UI] --> Server[127.0.0.1 service]
      Server --> SQLite[(SQLite)]
      Server --> Model[Local model]
    end
    Gmail[Gmail IMAP TLS] --> Server
    Server --> IPAPI[Selected public IP only]
    Server --> RDAP[Selected domain only]
```

Email content stays inside the local boundary. External enrichment receives only the selected indicator. Gmail credentials stay in process memory.

## Deployment architecture

The portable MVP runs as one local Python process. The production migration preserves module interfaces while replacing infrastructure:

| Prototype | Production migration |
|---|---|
| Standard-library gateway | FastAPI/Uvicorn behind TLS reverse proxy |
| Local analyst profile | JWT/OIDC and RBAC |
| SQLite | PostgreSQL |
| JSON graph representation | Neo4j or PostgreSQL graph model |
| In-process cache | Redis |
| Local PDF bytes | Object storage with retention policy |
| App Password IMAP | Google OAuth with organizational consent |

## Security boundaries

- Uploaded/pasted/authorized email only.
- Read-only Gmail mailbox selection.
- No attachment execution or active URL visiting.
- No random scanning, exploitation or unauthorized attribution.
- External failures return explicit unavailable states.
- Evidence source, status, timestamp and confidence are preserved.
