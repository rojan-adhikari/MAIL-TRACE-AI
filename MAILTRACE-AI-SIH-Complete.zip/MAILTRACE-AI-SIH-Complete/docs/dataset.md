# Dataset Strategy

## Bundled dataset

`data/dataset.json` contains 30 clearly labelled synthetic messages:

- 20 training samples
- 4 validation samples
- 6 test samples

The split field is authoritative. Training code reads only `split=train`; benchmark metrics are calculated only on `split=test`. No test sample is used to fit the model.

## Categories

- Legitimate organizational communication
- BEC payment diversion
- Executive impersonation
- Vendor fraud
- Credential harvesting
- Payroll diversion
- Sensitive-data request
- General phishing/impersonation

## Demonstration dataset

`data/demos.json` contains five safe synthetic investigations. IPs use documentation/test ranges and locations, ASNs, providers and identity data are explicitly synthetic fixtures.

## Future reproducible pipeline

1. Acquire legitimate research corpora under their applicable licences.
2. Normalize text and metadata without changing split identifiers.
3. Deduplicate by normalized-body hash before splitting.
4. Separate sender/domain/time clusters across train and test to reduce leakage.
5. Preserve immutable dataset manifests and hashes.
6. Evaluate overall, BEC, lookalike-domain and adversarial subsets.
7. Publish precision, recall, F1, ROC-AUC, false-positive rate and false-negative rate with sample counts.

Possible future sources include the Enron corpus, SpamAssassin public corpus, independently reviewed public phishing collections and carefully curated synthetic BEC examples. Sources must be cited and license/privacy conditions respected before inclusion.

## Limitation

The bundled dataset is intentionally too small to support a production-performance claim. Its purpose is offline reproducibility and transparent pipeline demonstration.
