# Judge Demonstration Script

## 90-second primary flow

1. Start MAILTRACE and point out **OFFLINE CORE READY**.
2. Point out the visible **Why MAILTRACE Exists** comparison, then click **RUN COMPLETE SIH DEMO**.
3. Explain that the loaded email is a safe synthetic CEO-impersonation BEC scenario.
4. Show the visible orchestrator progress from parsing to final assessment.
5. Present the critical threat score separately from evidence confidence.
6. Read **WHAT WE KNOW** and **WHAT WE DO NOT KNOW**.
7. Use the verdict shortcuts to open **Why This Verdict** and show structured evidence confidence.
8. Open **Relay Path** and explain trusted-boundary colors.
9. Open **Threat Graph** and identify Email → Sender → Domain → IP → ASN → Provider.
10. Open **IP + Location** and point to the confidence radius and infrastructure disclaimer; open **Sender + Device** to show only header-derived client clues.
11. Save the case and export the PDF.
12. Open the case ledger and show verified SHA-256 chaining.

On a narrow or zoomed display, use the persistent **☰ MODULES** button to move between the dashboard, investigation, graph, campaigns, reports and settings.

## Differentiation statement

“Gmail and spam filters decide whether to deliver a message. MAILTRACE investigates why it is suspicious, reconstructs available infrastructure evidence, correlates related cases and reports how much each conclusion should be trusted.”

## Campaign demonstration

Run **Lookalike-domain phishing** and **Credential harvesting**, save both, then open Campaigns. Their shared synthetic ASN/provider creates a correlated infrastructure cluster.

## Model-evaluation demonstration

Open Model Evaluation. State that metrics are calculated at runtime on the held-out synthetic test split. Emphasize the visible sample count and limitation rather than presenting the value as production accuracy.

## Gmail demonstration

Connect only an authorized demonstration account. Use a Google App Password, never the normal password. Show that the folder is opened read-only and save one suspicious message as a case.

## Closing statement

“The evidence strongly supports the displayed threat classification and infrastructure relationship. It does not establish the exact physical location, physical device or identity of the human operator. Those uncertainties are preserved in the report.”
