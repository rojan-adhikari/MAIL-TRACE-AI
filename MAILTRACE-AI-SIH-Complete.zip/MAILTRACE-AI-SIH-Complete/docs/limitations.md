# Limitations

## Attribution

- Received headers can be incomplete, forged or attacker-controlled before the trusted receiving boundary.
- A public IP can belong to a relay, VPN, proxy, cloud service or compromised host.
- IP geolocation estimates network infrastructure and can be wrong or stale.
- X-Mailer and User-Agent values can be absent or forged.
- Registration records do not prove who operated a campaign.

## Authentication

Offline analysis reads receiver-generated SPF, DKIM, DMARC and ARC results. It does not independently recreate historical DNS state or cryptographically verify every signature.

## Machine learning

The bundled dataset is small and synthetic. Runtime metrics demonstrate separation and reproducibility, not production accuracy. The transformer layer is not configured and no transformer result is fabricated.

## Threat intelligence

Keyless providers can be unavailable, rate limited or inaccurate. VPN/TOR values remain **NOT ASSESSED** when the configured provider does not supply them. Missing API keys display **NOT CONFIGURED**.

## Gmail

The portable monitor reads the Gmail INBOX using IMAP and an App Password. Google webmail may hide the original client IP and device. The MVP does not modify messages and does not monitor every organizational mailbox.

## Attachments

Attachments are hashed and checked for local filename/content-type indicators. They are not detonated or executed. Encrypted content cannot be inspected without authorized decryption.

## Production controls

The local prototype has a single analyst profile and does not implement production JWT/OIDC, multi-user RBAC, central key management, high availability, legal-hold workflows or certified evidentiary procedures.

## Reporting

The generated PDF is a prototype investigative report. Legal admissibility depends on jurisdiction, organizational procedure, analyst testimony and evidence-handling controls outside the application.

## Honest conclusion

MAILTRACE provides decision support and preserves uncertainty. It cannot guarantee detection, prevent every fraud attempt or independently identify a human attacker.
