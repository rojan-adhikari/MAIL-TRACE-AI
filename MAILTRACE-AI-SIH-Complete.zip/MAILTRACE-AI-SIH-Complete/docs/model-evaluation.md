# Model Evaluation

## Runtime evaluation

The Model Evaluation page trains a TF-IDF logistic-regression model when the Python process starts and calculates metrics on the held-out test split whenever `/api/benchmark` is called.

The response includes:

- Accuracy
- Precision
- Recall
- F1
- False-positive rate
- False-negative rate
- Confusion counts
- Average analysis time
- Safe adversarial stability

The transformer row displays **NOT CONFIGURED**. MAILTRACE does not fabricate transformer results.

## Hybrid model

The hybrid result combines the local language probability with structured behavior groups. The final email verdict additionally uses authentication, identity, domain, URL, attachment, route and temporal evidence. Therefore model probability is not the verdict.

## Adversarial check

Safe transformations include:

- Benign sentence insertion
- Whitespace insertion
- Punctuation removal
- Safe paraphrasing

No live phishing message or attack is generated.

## Interpretation

High metrics on six synthetic test samples are statistically weak. The interface always displays the sample count and limitation. A credible production study needs a much larger independent test set, confidence intervals, organization-specific false-positive analysis and adversarial red-team evaluation.
