# Research and Differentiation

## Existing approaches

Common email-security systems focus on spam probability, content signatures, sender reputation and delivery-time blocking. Header-analysis utilities often display SPF, DKIM and DMARC results independently. URL and IP reputation services usually analyze a single indicator. SIEM products can correlate events, but email-specific forensic reconstruction is often manual.

## Weaknesses addressed

1. **Classifier-only verdicts** — a phishing label does not preserve the evidence needed for investigation.
2. **Authentication-only scoring** — a domain controlled by an attacker can pass SPF and DKIM while delivering BEC content.
3. **Blind oldest-header origin claims** — older Received headers may be forged or attacker-controlled.
4. **False precision in IP geolocation** — city markers are often presented as exact attacker locations.
5. **Isolated indicators** — domains, URLs, IPs, ASNs, reply identities and attachment hashes are not shown as a connected campaign graph.
6. **Unqualified AI explanations** — language models can invent technical evidence when not constrained to structured facts.
7. **No confidence separation** — threat probability and source reliability answer different questions.
8. **No chain of custody** — evidence can be changed without a detectable record.

## MAILTRACE AI differentiation

- Evidence fusion across independent categories rather than SPF/DKIM/DMARC multiplication.
- Separate **Threat Score** and **Evidence Confidence**.
- Trusted-boundary analysis for every Received hop.
- A Threat Infrastructure Graph connecting emails, identities, domains, IPs, ASNs, providers, URLs, attachments and campaigns.
- Explicit **WHAT WE KNOW** and **WHAT WE DO NOT KNOW** sections.
- Probable network location with a confidence radius and infrastructure disclaimer.
- Runtime-reproducible lightweight ML metrics and safe adversarial variations.
- Tamper-evident SHA-256 chain for saved evidence.
- Offline-first synthetic demo with no fabricated live API response.

## Design principle

Detection tells an analyst that an email may be dangerous. Forensics explains why. Correlation shows what it is connected to. Evidence confidence describes how strongly the available sources support the conclusion.

## Honest prototype boundary

The included synthetic dataset and local model prove reproducibility and workflow integration, not production accuracy. Production evaluation requires a larger, independently curated corpus, organization-specific trust boundaries and formal red-team testing.
