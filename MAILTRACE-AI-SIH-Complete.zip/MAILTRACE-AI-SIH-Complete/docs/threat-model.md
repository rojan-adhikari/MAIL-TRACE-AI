# Threat Model

## Assets

- Gmail App Password held in process memory.
- Email headers, message text and attachment hashes.
- Investigation cases, analyst notes and decisions.
- Evidence ledger and PDF reports.
- Optional threat-intelligence API keys in environment variables.

## Trust boundaries

1. Browser to local service on `127.0.0.1`.
2. Local service to Gmail over IMAPS/TLS.
3. Local service to selected public-intelligence endpoints.
4. Local service to SQLite case storage.

## Threats and controls

| Threat | Control |
|---|---|
| Credential theft | App Password never written to disk; password field cleared; no frontend keys |
| Malicious attachment execution | Attachments decoded only for hashing; never opened or executed |
| SSRF through arbitrary URLs | Analyzer parses URL text but does not visit message URLs |
| Local service exposure | Defaults to `127.0.0.1`; restrictive CSP and no CORS |
| Evidence modification | SHA-256 evidence hashes and previous-hash chain verification |
| PII leakage | Privacy mode masks email addresses before case storage |
| External provider failure | Timeout, error boundary and explicit local fallback |
| Geolocation overclaim | Infrastructure disclaimer, confidence and attribution-not-determined label |
| Header forgery | Trusted-boundary and uncertainty labels per relay hop |
| Model evasion | Hybrid evidence sources and safe mutation stability check |
| Model hallucination | Local model contributes only language probability; technical facts come from parsers |

## Out of scope for the portable MVP

- Multi-user authentication, production JWT/OIDC and fine-grained RBAC.
- Malware detonation and attachment sandboxing.
- Active scanning, exploitation or takedown.
- Guaranteed actor attribution.
- Legal admissibility certification; organizations must follow their own evidence procedures.

## Abuse-prevention principle

MAILTRACE analyzes data supplied or authorized by the analyst and public records for extracted indicators. It does not scan arbitrary systems or send emails.
