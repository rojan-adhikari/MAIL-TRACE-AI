"""MAILTRACE AI — evidence-driven email investigation prototype."""

__version__ = "1.0.0-sih-prototype"
