"""Deterministic email forensics and evidence-fusion engine."""

from __future__ import annotations

import hashlib
import ipaddress
import math
import re
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from email import policy
from email.parser import Parser
from email.utils import parseaddr, parsedate_to_datetime
from html.parser import HTMLParser
from typing import Any, Literal
from urllib.parse import urlparse

from .model import LightweightThreatModel


Severity = Literal["critical", "high", "medium", "low", "info"]
Status = Literal["FACT", "INFERENCE", "UNCERTAINTY"]


@dataclass
class Evidence:
    id: str
    title: str
    explanation: str
    severity: Severity
    confidence: int
    evidence_type: str
    source: str
    status: Status
    timestamp: str


class BodyParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.text_parts: list[str] = []
        self.links: list[dict[str, str]] = []
        self._href: str | None = None
        self._anchor_text: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "a":
            self._href = next((value for name, value in attrs if name.lower() == "href" and value), None)
            self._anchor_text = []

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._href:
            self.links.append({"href": self._href, "text": " ".join(self._anchor_text).strip()})
            self._href = None
            self._anchor_text = []

    def handle_data(self, data: str) -> None:
        self.text_parts.append(data)
        if self._href:
            self._anchor_text.append(data)


def extract_body(message) -> tuple[str, list[dict[str, str]]]:
    plain: list[str] = []
    html: list[str] = []
    parts = list(message.walk()) if message.is_multipart() else [message]
    for part in parts:
        if part.get_content_disposition() == "attachment":
            continue
        if part.get_content_type() not in ("text/plain", "text/html"):
            continue
        try:
            value = str(part.get_content())
        except Exception:
            payload = part.get_payload(decode=True) or b""
            value = payload.decode(part.get_content_charset() or "utf-8", errors="replace")
        (html if part.get_content_type() == "text/html" else plain).append(value)
    parser = BodyParser()
    for value in html:
        try:
            parser.feed(value)
        except Exception:
            parser.text_parts.append(value)
    text = "\n".join(plain) if plain else " ".join(parser.text_parts)
    return text[:500_000], parser.links


def domain_of(value: str) -> str:
    address = parseaddr(value)[1].lower()
    return address.rsplit("@", 1)[-1] if "@" in address else "unknown"


def levenshtein(left: str, right: str) -> int:
    if len(left) < len(right):
        left, right = right, left
    previous = list(range(len(right) + 1))
    for index, left_character in enumerate(left, start=1):
        current = [index]
        for other_index, right_character in enumerate(right, start=1):
            current.append(min(current[-1] + 1, previous[other_index] + 1, previous[other_index - 1] + (left_character != right_character)))
        previous = current
    return previous[-1]


def jaro_winkler(left: str, right: str) -> float:
    if left == right:
        return 1.0
    if not left or not right:
        return 0.0
    window = max(len(left), len(right)) // 2 - 1
    left_matches = [False] * len(left)
    right_matches = [False] * len(right)
    matches = 0
    for i, char in enumerate(left):
        for j in range(max(0, i - window), min(i + window + 1, len(right))):
            if not right_matches[j] and char == right[j]:
                left_matches[i] = right_matches[j] = True
                matches += 1
                break
    if not matches:
        return 0.0
    left_chars = [left[i] for i in range(len(left)) if left_matches[i]]
    right_chars = [right[i] for i in range(len(right)) if right_matches[i]]
    transpositions = sum(a != b for a, b in zip(left_chars, right_chars)) / 2
    jaro = (matches / len(left) + matches / len(right) + (matches - transpositions) / matches) / 3
    prefix = 0
    for a, b in zip(left[:4], right[:4]):
        if a != b:
            break
        prefix += 1
    return jaro + prefix * 0.1 * (1 - jaro)


CONFUSABLES = str.maketrans({"0": "o", "1": "l", "3": "e", "5": "s", "7": "t", "@": "a"})


def normalized_domain(domain: str) -> str:
    try:
        decoded = domain.encode("ascii").decode("idna")
    except (UnicodeError, UnicodeEncodeError):
        decoded = domain
    return re.sub(r"[^a-z0-9]", "", decoded.lower().translate(CONFUSABLES).split(".")[0])


def domain_similarity(observed: str, protected: str) -> dict[str, Any]:
    left, right = normalized_domain(observed), normalized_domain(protected)
    longest = max(len(left), len(right), 1)
    character = max(0, 1 - levenshtein(left, right) / longest)
    jaro = jaro_winkler(left, right)
    protected_brand = re.sub(r"[^a-z0-9]", "", protected.split(".")[0].split("-")[0].lower())
    token = 1.0 if right and (right in left or left in right or (len(protected_brand) >= 4 and protected_brand in left)) else 0.0
    unicode_confusable = 1.0 if observed.startswith("xn--") or any(ord(value) > 127 for value in observed) else 0.0
    overall = max(character * 0.55 + jaro * 0.35 + token * 0.1, 0.9 if token else 0.0)
    return {
        "protectedDomain": protected, "levenshteinDistance": levenshtein(left, right),
        "characterSimilarity": round(character * 100), "jaroWinkler": round(jaro * 100),
        "brandTokenSimilarity": round(token * 100), "unicodeConfusable": bool(unicode_confusable),
        "overall": round(overall * 100),
    }


IPV4_RE = re.compile(r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])")


def ip_values(value: str) -> list[ipaddress.IPv4Address | ipaddress.IPv6Address]:
    candidates = IPV4_RE.findall(value)
    candidates.extend(match.strip().removeprefix("IPv6:") for match in re.findall(r"\[([^\]]+)\]", value))
    result: list[ipaddress.IPv4Address | ipaddress.IPv6Address] = []
    for candidate in candidates:
        try:
            ip = ipaddress.ip_address(candidate.split("%", 1)[0].strip())
        except ValueError:
            continue
        if ip not in result:
            result.append(ip)
    return result


def ip_scope(ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> str:
    if ip.is_global:
        return "PUBLIC"
    if ip.is_private:
        return "PRIVATE/TEST"
    if ip.is_loopback:
        return "LOOPBACK"
    if ip.is_link_local:
        return "LINK_LOCAL"
    return "RESERVED"


def host_after(value: str, marker: str) -> str:
    match = re.search(rf"\b{marker}\s+([^\s(;]+)", value, flags=re.IGNORECASE)
    return match.group(1).strip("[]") if match else "Not disclosed"


def parse_header_time(value: str) -> tuple[str, datetime | None]:
    if ";" not in value:
        return "Not disclosed", None
    supplied = value.rsplit(";", 1)[-1].strip()
    try:
        parsed = parsedate_to_datetime(supplied)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.isoformat(), parsed
    except (ValueError, TypeError, OverflowError):
        return supplied or "Malformed", None


def reconstruct_route(message) -> list[dict[str, Any]]:
    headers = [str(value) for value in message.get_all("Received", [])]
    route: list[dict[str, Any]] = []
    previous: datetime | None = None
    for index, value in enumerate(reversed(headers), start=1):
        ips = [{"ip": str(ip), "scope": ip_scope(ip)} for ip in ip_values(value)]
        timestamp, parsed = parse_header_time(value)
        anomaly = bool(parsed and previous and parsed < previous)
        if parsed:
            previous = parsed
        by_host = host_after(value, "by")
        trusted_receiver = bool(re.search(r"(?:^|\.)(?:google\.com|googlemail\.com)$", by_host, flags=re.IGNORECASE))
        if anomaly:
            trust, confidence = "RED", 88
            reason = "Timestamp contradicts the preceding reconstructed hop."
        elif trusted_receiver:
            trust, confidence = "GREEN", 94
            reason = "Header appears to have been added by the recipient-side Google boundary."
        elif ips:
            trust, confidence = "YELLOW", 58
            reason = "Header is syntactically valid but may come from external or sender-controlled infrastructure."
        else:
            trust, confidence = "YELLOW", 30
            reason = "No verifiable IP was present in this hop."
        route.append({
            "hop": index, "fromHostname": host_after(value, "from"), "byHostname": by_host,
            "ips": ips, "timestamp": timestamp, "trustLevel": trust, "trustConfidence": confidence,
            "trustReason": reason, "timeAnomaly": anomaly, "raw": value[:1200],
        })
    return route


def device_clues(message) -> dict[str, Any]:
    clues = []
    for header in ("X-Mailer", "User-Agent", "X-MimeOLE"):
        value = str(message.get(header, "")).strip()
        if value:
            clues.append({"header": header, "value": value, "confidence": 65, "status": "FACT: header value; device inference remains uncertain"})
    combined = " ".join(item["value"] for item in clues).lower()
    patterns = (
        (r"iphone|ios", "Possible iPhone/iOS mail client"), (r"ipad", "Possible iPad/iPadOS mail client"),
        (r"android", "Possible Android mail client"), (r"outlook|microsoft office", "Microsoft Outlook-compatible client"),
        (r"apple mail|macintosh|mac os", "Possible Apple Mail/macOS client"), (r"thunderbird", "Mozilla Thunderbird client"),
    )
    inferred = next((label for pattern, label in patterns if re.search(pattern, combined)), "Not determinable from headers")
    return {"inferred": inferred, "confidence": 58 if inferred != "Not determinable from headers" else 0, "clues": clues, "physicalDeviceKnown": False}


def attachment_indicators(message, body: str) -> list[dict[str, Any]]:
    indicators: list[dict[str, Any]] = []
    for part in message.walk() if message.is_multipart() else []:
        filename = part.get_filename()
        if not filename and part.get_content_disposition() != "attachment":
            continue
        payload = part.get_payload(decode=True) or b""
        extension = (filename or "unnamed").rsplit(".", 1)[-1].lower()
        indicators.append({
            "filename": filename or "unnamed attachment", "contentType": part.get_content_type(), "sizeBytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest(), "dangerousExtension": extension in {"exe", "scr", "js", "vbs", "iso", "img", "lnk", "zip"},
            "encrypted": part.get_content_type() in {"application/pkcs7-mime", "application/pgp-encrypted"}, "executed": False,
        })
    if not indicators:
        for filename in re.findall(r"\b[\w.-]+\.(?:zip|iso|img|exe|scr|js|vbs|lnk)\b", body, flags=re.IGNORECASE)[:5]:
            indicators.append({"filename": filename, "contentType": "Mentioned in message text", "sizeBytes": None, "sha256": "Unavailable — file bytes not supplied", "dangerousExtension": True, "encrypted": False, "executed": False, "status": "INFERENCE"})
    return indicators


def url_indicators(body: str, anchor_links: list[dict[str, str]]) -> list[dict[str, Any]]:
    values = re.findall(r"https?://[^\s<>\"']+", body, flags=re.IGNORECASE)
    values.extend(item["href"] for item in anchor_links)
    result: list[dict[str, Any]] = []
    shorteners = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly"}
    for value in list(dict.fromkeys(values))[:25]:
        cleaned = value.rstrip(".,);]")
        parsed = urlparse(cleaned)
        host = (parsed.hostname or "").lower()
        anchor = next((item for item in anchor_links if item["href"] == value), None)
        shown_host = ""
        if anchor:
            match = re.search(r"https?://([^/\s]+)", anchor["text"], flags=re.IGNORECASE)
            shown_host = match.group(1).lower() if match else ""
        flags = []
        if host in shorteners:
            flags.append("SHORTENED_URL")
        try:
            ipaddress.ip_address(host)
            flags.append("IP_BASED_URL")
        except ValueError:
            pass
        if host.startswith("xn--") or ".xn--" in host:
            flags.append("PUNYCODE")
        if len(host.split(".")) > 4:
            flags.append("EXCESSIVE_SUBDOMAINS")
        if re.search(r"login|verify|secure|account|password|credential|session|redirect", cleaned, flags=re.IGNORECASE):
            flags.append("ACCOUNT_ACTION_SEMANTICS")
        if shown_host and shown_host != host:
            flags.append("ANCHOR_DESTINATION_MISMATCH")
        if re.search(r"(?:url|target|redirect|continue)=https?", parsed.query, flags=re.IGNORECASE):
            flags.append("REDIRECT_PARAMETER")
        result.append({"url": cleaned, "host": host or "malformed", "anchorText": anchor["text"] if anchor else "Not applicable", "displayedHost": shown_host or "Not disclosed", "flags": list(dict.fromkeys(flags)), "reputation": "NOT CONFIGURED", "redirectChain": [cleaned]})
    return result


def graph_from(analysis_id: str, sender: str, sender_domain: str, reply_to: str, route: list[dict[str, Any]], urls: list[dict[str, Any]], attachments: list[dict[str, Any]], fixture: dict[str, Any] | None) -> dict[str, list[dict[str, Any]]]:
    nodes: list[dict[str, Any]] = [{"id": analysis_id, "type": "Email", "label": analysis_id}, {"id": f"sender:{sender}", "type": "Sender", "label": sender}, {"id": f"domain:{sender_domain}", "type": "Domain", "label": sender_domain}]
    edges = [{"source": analysis_id, "target": f"sender:{sender}", "type": "SENT_FROM"}, {"source": f"sender:{sender}", "target": f"domain:{sender_domain}", "type": "USES_DOMAIN"}]
    if reply_to != "Not present":
        nodes.append({"id": f"reply:{reply_to}", "type": "Reply-To", "label": reply_to})
        edges.append({"source": analysis_id, "target": f"reply:{reply_to}", "type": "REPLIED_TO"})
    seen_ips: set[str] = set()
    for hop in route:
        server_id = f"server:{hop['byHostname']}"
        if hop["byHostname"] != "Not disclosed" and not any(node["id"] == server_id for node in nodes):
            nodes.append({"id": server_id, "type": "Mail Server", "label": hop["byHostname"]})
            edges.append({"source": analysis_id, "target": server_id, "type": "RELAYED_THROUGH"})
        for value in hop["ips"]:
            ip = value["ip"]
            if ip not in seen_ips:
                seen_ips.add(ip)
                nodes.append({"id": f"ip:{ip}", "type": "IP", "label": ip})
                edges.append({"source": f"domain:{sender_domain}", "target": f"ip:{ip}", "type": "OBSERVED_ON"})
    if fixture:
        asn = str(fixture.get("asn") or "ASN unavailable")
        provider = str(fixture.get("organization") or "Provider unavailable")
        nodes.extend([{"id": f"asn:{asn}", "type": "ASN", "label": asn}, {"id": f"provider:{provider}", "type": "Hosting Provider", "label": provider}])
        for ip in seen_ips:
            edges.append({"source": f"ip:{ip}", "target": f"asn:{asn}", "type": "HOSTED_ON"})
        edges.append({"source": f"asn:{asn}", "target": f"provider:{provider}", "type": "OPERATED_BY"})
    for index, item in enumerate(urls):
        node_id = f"url:{index}:{item['host']}"
        nodes.append({"id": node_id, "type": "URL", "label": item["host"]})
        edges.append({"source": analysis_id, "target": node_id, "type": "CONTAINS_URL"})
    for index, item in enumerate(attachments):
        node_id = f"attachment:{index}:{item['sha256'][:12]}"
        nodes.append({"id": node_id, "type": "Attachment hash", "label": item["filename"]})
        edges.append({"source": analysis_id, "target": node_id, "type": "CONTAINS_ATTACHMENT"})
    return {"nodes": nodes, "edges": edges}


class InvestigationEngine:
    def __init__(self, model: LightweightThreatModel, protected_domains: list[str] | None = None) -> None:
        self.model = model
        self.protected_domains = [value.lower() for value in (protected_domains or ["aicte-india.org", "gmail.com", "sbi.co.in"])]

    def analyze(self, raw: str, fixture: dict[str, Any] | None = None, synthetic: bool = False) -> dict[str, Any]:
        started = time.perf_counter()
        if not raw.strip():
            raise ValueError("Paste or write an email before starting the investigation.")
        message = Parser(policy=policy.default).parsestr(raw[:2_000_000])
        body, anchors = extract_body(message)
        now = datetime.now(timezone.utc).isoformat()
        sender_display = str(message.get("From", "Not present"))
        sender_name, sender_address = parseaddr(sender_display)
        sender_address = sender_address.lower() or "unknown"
        sender_domain = domain_of(sender_display)
        reply_to = parseaddr(str(message.get("Reply-To", "")))[1].lower() or "Not present"
        return_path = parseaddr(str(message.get("Return-Path", "")))[1].lower() or "Not present"
        subject = str(message.get("Subject", "No subject"))
        combined = f"{subject}\n{body}"
        normalized = combined.lower()
        evidence: list[Evidence] = []

        def add(title: str, explanation: str, severity: Severity, confidence: int, evidence_type: str, source: str, status: Status) -> None:
            evidence.append(Evidence(f"EV-{len(evidence)+1:03d}", title, explanation, severity, confidence, evidence_type, source, status, now))

        authentication_text = " ".join(str(value) for value in message.get_all("Authentication-Results", [])).lower()
        authentication: dict[str, dict[str, Any]] = {}
        for method in ("spf", "dkim", "dmarc", "arc"):
            match = re.search(rf"\b{method}=([a-z_-]+)", authentication_text)
            result = match.group(1).upper() if match else "NOT PRESENT"
            authentication[method.upper()] = {"result": result, "confidence": 99 if match else 96, "source": "Receiver-reported Authentication-Results"}
            if result == "PASS":
                add(f"{method.upper()} validation passed", f"The receiver-reported result is {result}. A pass does not prove benign intent.", "info", 99, "EMAIL_AUTHENTICATION", "Authentication-Results", "FACT")
            elif result in {"FAIL", "SOFTFAIL", "PERMERROR"}:
                add(f"{method.upper()} validation problem", f"The receiver-reported result is {result}.", "high" if method == "dmarc" else "medium", 99, "EMAIL_AUTHENTICATION", "Authentication-Results", "FACT")
        if not authentication_text:
            add("Authentication results unavailable", "No Authentication-Results header was supplied; local parsing cannot recreate the receiver's cryptographic checks.", "low", 99, "AUTH_COVERAGE", "Header parser", "UNCERTAINTY")

        reply_domain = domain_of(reply_to)
        return_domain = domain_of(return_path)
        if reply_to != "Not present" and reply_domain != sender_domain:
            add("Reply-To identity mismatch", f"Replies are redirected from {sender_domain} to {reply_domain}.", "high", 97, "SENDER_IDENTITY", "Header parser", "FACT")
        if return_path != "Not present" and return_domain != sender_domain:
            add("Return-Path identity mismatch", f"Bounce handling uses {return_domain}, different from visible domain {sender_domain}.", "medium", 92, "SENDER_IDENTITY", "Header parser", "FACT")
        if re.search(r"\b(ceo|cfo|chairman|director|president|registrar|finance head)\b", sender_name.lower()):
            add("Executive or protected-role claim", f"The display name claims the role '{sender_name}'.", "medium", 87, "DISPLAY_NAME", "Identity analyzer", "INFERENCE")

        similarities = [domain_similarity(sender_domain, protected) for protected in self.protected_domains if sender_domain != "unknown" and sender_domain != protected]
        closest = max(similarities, key=lambda item: item["overall"], default={"overall": 0, "protectedDomain": "Not applicable"})
        if closest["overall"] >= 68:
            add("Lookalike sender domain", f"{sender_domain} has {closest['overall']}% composite similarity to protected domain {closest['protectedDomain']}.", "high", min(96, closest["overall"]), "DOMAIN_SIMILARITY", "Local lookalike engine", "INFERENCE")
        if sender_domain.startswith("xn--") or ".xn--" in sender_domain:
            add("Punycode/IDN sender domain", "The sender domain uses Punycode and requires Unicode-confusable review.", "high", 96, "DOMAIN_SIMILARITY", "IDNA parser", "FACT")
        tld = sender_domain.rsplit(".", 1)[-1] if "." in sender_domain else ""
        tld_risk = "ELEVATED" if tld in {"top", "xyz", "click", "zip", "mov", "country", "work"} else "NORMAL/UNKNOWN"
        if tld_risk == "ELEVATED":
            add("Elevated-risk TLD", f"The .{tld} TLD is treated as a weak contextual risk signal, not proof of abuse.", "low", 62, "DOMAIN_INTELLIGENCE", "Local TLD policy", "INFERENCE")

        urls = url_indicators(body, anchors)
        for item in urls:
            if item["flags"]:
                add("Suspicious URL structure", f"{item['host']} triggered: {', '.join(item['flags'])}.", "high" if "ANCHOR_DESTINATION_MISMATCH" in item["flags"] else "medium", 88, "URL_INTELLIGENCE", "Local URL parser", "INFERENCE")
        attachments = attachment_indicators(message, body)
        for item in attachments:
            if item["dangerousExtension"]:
                add("Risky attachment indicator", f"{item['filename']} uses an extension frequently abused for delivery. The file was not opened or executed.", "high", 86, "ATTACHMENT", "MIME/filename analyzer", item.get("status", "FACT"))

        bec_patterns = [
            ("BEC_PAYMENT", "Payment-diversion request", r"beneficiary|bank account.{0,25}changed|wire transfer|confirm.{0,15}transfer|invoice payment", 94),
            ("BEC_EXECUTIVE", "Executive impersonation behavior", r"gift cards?|i am (?:the )?(?:ceo|chairman|director)|closed meeting", 91),
            ("BEC_VENDOR", "Supplier or vendor fraud behavior", r"supplier|vendor|revised invoice|new account", 88),
            ("BEC_CREDENTIAL", "Credential-harvesting request", r"username and password|submit credentials|verify.{0,25}(?:account|mailbox)|mailbox.{0,20}(?:disabled|suspended|expires)", 94),
            ("BEC_PAYROLL", "Payroll-change request", r"payroll|direct deposit|salary account", 91),
            ("BEC_DATA_REQUEST", "Sensitive-data request", r"employee.{0,20}(?:records|tax)|student database|confidential.{0,20}records", 89),
            ("BEC_SECRECY", "Secrecy and channel-control behavior", r"keep.{0,20}(?:confidential|secret)|do not call|between us|reply immediately", 94),
            ("TEMPORAL_ANOMALY", "Artificial urgency", r"urgent|immediately|within (?:one|\d+) hour|today only|without delay", 86),
        ]
        bec_types: list[str] = []
        for evidence_type, title, pattern, confidence in bec_patterns:
            if re.search(pattern, normalized):
                bec_types.append(evidence_type)
                add(title, f"The requested action and surrounding context match the {evidence_type} behavior group.", "medium" if evidence_type == "TEMPORAL_ANOMALY" else "high", confidence, evidence_type, "Behavioral/BEC engine", "INFERENCE")

        ml_probability = self.model.predict_probability(combined)
        hybrid_probability = self.model.hybrid_probability(combined)
        if hybrid_probability >= 0.5:
            add("Local ML threat classification", f"The runtime TF-IDF model and behavioral layer produced {round(hybrid_probability*100)}% malicious-language probability.", "medium", round(max(55, hybrid_probability * 100)), "AI_LANGUAGE", "Local lightweight model", "INFERENCE")
        else:
            add("Local ML low-risk language assessment", f"The lightweight model produced {round(hybrid_probability*100)}% malicious-language probability.", "info", round(max(55, (1-hybrid_probability) * 100)), "AI_LANGUAGE", "Local lightweight model", "INFERENCE")

        route = reconstruct_route(message)
        if not route:
            add("Relay path unavailable", "No Received headers were supplied, so the transmission route and origin cannot be reconstructed.", "low", 99, "ROUTE_COVERAGE", "Header parser", "UNCERTAINTY")
        if any(hop["timeAnomaly"] for hop in route):
            add("Relay timestamp contradiction", "At least one hop timestamp contradicts the reconstructed order.", "medium", 88, "TEMPORAL_ANOMALY", "Route analyzer", "FACT")
        public_or_test_ips = [row["ip"] for hop in route for row in hop["ips"] if row["scope"] in {"PUBLIC", "PRIVATE/TEST"}]
        explicit = [str(ip) for header in ("X-Originating-IP", "X-Sender-IP", "X-Client-IP") for value in message.get_all(header, []) for ip in ip_values(str(value))]
        observed_ips = list(dict.fromkeys(explicit + public_or_test_ips))
        primary_ip = explicit[0] if explicit else (public_or_test_ips[0] if public_or_test_ips else None)
        primary_basis = "Originating-IP header" if explicit else "Earliest visible address in the reconstructed route" if primary_ip else "No usable address disclosed"
        primary_confidence = 70 if explicit else 55 if primary_ip else 0

        device = device_clues(message)
        dkim_domains = sorted(set(re.findall(r"(?:^|;)\s*d=([^;\s]+)", " ".join(str(value) for value in message.get_all("DKIM-Signature", [])), flags=re.IGNORECASE)))
        tls = sorted(set(re.findall(r"\b(?:ESMTPSA?|SMTPS|TLSv?\d(?:\.\d)?)\b", " ".join(str(value) for value in message.get_all("Received", [])), flags=re.IGNORECASE)))

        severity_points = {"critical": 22, "high": 16, "medium": 9, "low": 4, "info": 0}
        grouped: dict[str, float] = {}
        for item in evidence:
            # Cap duplicates within the same evidence category while allowing
            # independent categories (identity, URL, BEC, temporal, AI, etc.)
            # to contribute separately to evidence fusion.
            family = item.evidence_type
            grouped[family] = max(grouped.get(family, 0), severity_points[item.severity] * item.confidence / 100)
        threat_score = min(98, round(sum(grouped.values())))
        if len([item for item in evidence if item.severity == "high"]) >= 4:
            threat_score = min(98, threat_score + 10)
        risky = [item for item in evidence if item.severity != "info"]
        evidence_confidence = round(sum(item.confidence for item in risky) / len(risky)) if risky else 88
        if not route:
            evidence_confidence = max(45, evidence_confidence - 8)
        severity = "CRITICAL" if threat_score >= 78 else "HIGH" if threat_score >= 55 else "MEDIUM" if threat_score >= 30 else "LOW"
        types = {item.evidence_type for item in evidence}
        if "DOMAIN_SIMILARITY" in types and "BEC_CREDENTIAL" in types:
            classification = "Lookalike-domain credential phishing"
        elif "BEC_PAYMENT" in types:
            classification = "Payment Diversion BEC"
        elif "BEC_EXECUTIVE" in types:
            classification = "Executive Impersonation BEC"
        elif "BEC_CREDENTIAL" in types:
            classification = "Credential Harvesting"
        elif "DOMAIN_SIMILARITY" in types:
            classification = "Lookalike-domain phishing"
        elif threat_score < 30:
            classification = "Likely legitimate"
        else:
            classification = "Suspicious email"

        digest = hashlib.sha256(raw.replace("\r\n", "\n").encode("utf-8", errors="replace")).hexdigest()
        analysis_id = f"INV-{digest[:8].upper()}"
        geolocation = None
        if fixture and (not primary_ip or fixture.get("ip") == primary_ip):
            geolocation = {
                **fixture, "source": "Synthetic demonstration fixture", "synthetic": True,
                "attribution": "NOT DETERMINED", "accuracy": "Simulated confidence radius: 120 km",
                "disclaimer": "Synthetic infrastructure location for demonstration only; not independently verified.",
            }
        graph = graph_from(analysis_id, sender_address, sender_domain, reply_to, route, urls, attachments, geolocation)
        indicators = [{"type": "DOMAIN", "value": sender_domain, "confidence": closest.get("overall", 50)}]
        indicators.extend({"type": "IP", "value": value, "confidence": primary_confidence if value == primary_ip else 50} for value in observed_ips)
        indicators.extend({"type": "URL", "value": item["url"], "confidence": 88 if item["flags"] else 55} for item in urls)
        indicators.extend({"type": "ATTACHMENT_SHA256", "value": item["sha256"], "confidence": 99} for item in attachments if not str(item["sha256"]).startswith("Unavailable"))
        if geolocation:
            indicators.append({"type": "ASN", "value": str(geolocation.get("asn", "Unavailable")), "confidence": geolocation.get("confidence", 70)})
            indicators.append({"type": "PROVIDER", "value": str(geolocation.get("organization", "Unavailable")), "confidence": geolocation.get("confidence", 70)})
        facts = [item.title for item in evidence if item.status == "FACT"]
        inferences = [item.title for item in evidence if item.status == "INFERENCE"]
        conclusion = f"The message is assessed as {classification.lower()} with a threat score of {threat_score}/100. "
        if risky:
            conclusion += "The assessment is supported by sender-identity, authentication, behavioral, URL, attachment and routing evidence where available. "
        conclusion += "Observed network data supports infrastructure investigation only and is insufficient to establish the physical location or identity of the human operator."
        reliability = [
            {"source": "Receiver authentication results", "confidence": 99 if authentication_text else 0},
            {"source": "Header identity parsing", "confidence": 96},
            {"source": "Lookalike-domain analysis", "confidence": closest.get("overall", 0)},
            {"source": "Observed route/IP", "confidence": primary_confidence},
            {"source": "Device/mail-client clue", "confidence": device["confidence"]},
            {"source": "Geolocation", "confidence": geolocation.get("confidence", 0) if geolocation else 0},
            {"source": "Local language model", "confidence": round(abs(hybrid_probability - 0.5) * 2 * 100)},
        ]
        performance_ms = round((time.perf_counter() - started) * 1000, 2)
        return {
            "analysisId": analysis_id, "timestamp": now, "synthetic": synthetic, "sourceMode": "SYNTHETIC DEMO" if synthetic else "LOCAL/LIVE INPUT",
            "subject": subject, "sender": sender_address, "senderDisplay": sender_display, "senderDomain": sender_domain,
            "replyTo": reply_to, "returnPath": return_path, "messageId": str(message.get("Message-ID", "Not present")), "date": str(message.get("Date", "Not present")),
            "threatScore": threat_score, "evidenceConfidence": evidence_confidence, "severity": severity, "classification": classification,
            "evidence": [asdict(item) for item in evidence], "reliability": reliability, "authentication": authentication,
            "domainIntelligence": {"domain": sender_domain, "closestProtectedDomain": closest, "tldRisk": tld_risk, "idnPunycode": sender_domain.startswith("xn--") or ".xn--" in sender_domain, "domainAge": "Not configured/offline", "registrar": "Not configured/offline", "dns": "External enrichment not requested"},
            "urls": urls, "attachments": attachments, "becTypes": bec_types, "ml": {"baselineProbability": round(ml_probability*100), "hybridProbability": round(hybrid_probability*100), "model": "Runtime TF-IDF logistic regression", "llm": "NOT CONFIGURED — no evidence was generated by an LLM"},
            "evasionCheck": self.model.evasion_check(combined), "route": route, "observedIps": observed_ips,
            "primaryObservedIp": {"ip": primary_ip, "basis": primary_basis, "confidence": primary_confidence, "attribution": "NOT DETERMINED"} if primary_ip else None,
            "device": device, "tlsIndicators": tls, "dkimSigningDomains": dkim_domains, "geolocation": geolocation,
            "graph": graph, "indicators": indicators, "sha256": digest, "performanceMs": performance_ms,
            "known": (facts + inferences)[:8],
            "unknown": ["Exact physical location of the sender", "Identity of the human operator", "Physical device identity when headers do not disclose it", "Whether observed infrastructure is compromised or operator-controlled"],
            "conclusion": conclusion,
            "limitations": ["Authentication values are receiver-reported header evidence, not independently re-run in offline mode.", "IP geolocation identifies probable network infrastructure, not a person.", "The local ML model uses a small synthetic dataset and is not a production accuracy claim.", "External reputation, DNS and RDAP data are labelled unavailable when not configured."],
        }
