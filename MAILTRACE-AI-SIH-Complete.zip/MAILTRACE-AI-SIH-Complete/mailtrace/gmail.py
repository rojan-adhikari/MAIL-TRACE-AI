"""Read-only Gmail IMAP monitor for the local prototype."""

from __future__ import annotations

import imaplib
import secrets
import ssl
import threading
import time
from typing import Any

from .forensics import InvestigationEngine
from .storage import CaseStore


class GmailMonitor:
    def __init__(self, engine: InvestigationEngine, store: CaseStore) -> None:
        self.engine = engine
        self.store = store
        self.lock = threading.RLock()
        self.connected = False
        self.account = ""
        self.status_message = "Not connected"
        self.sync_total = 0
        self.sync_count = 0
        self.sync_complete = False
        self.last_uid = 0
        self.messages: list[dict[str, Any]] = []
        self.details: dict[int, dict[str, Any]] = {}
        self.alerts: list[dict[str, Any]] = []
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._generation = 0

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return {
                "connected": self.connected, "account": self.account, "status": self.status_message,
                "syncTotal": self.sync_total, "syncCount": self.sync_count,
                "syncProgress": round(self.sync_count / self.sync_total * 100) if self.sync_total else 0,
                "syncComplete": self.sync_complete, "messageCount": len(self.messages), "alertCount": len(self.alerts),
                "folder": "INBOX", "readOnly": True,
            }

    def page(self, offset: int, limit: int) -> dict[str, Any]:
        with self.lock:
            ordered = sorted(self.messages, key=lambda item: item["uid"], reverse=True)
            offset, limit = max(0, offset), max(1, min(limit, 100))
            return {"messages": ordered[offset:offset+limit], "offset": offset, "limit": limit, "total": len(ordered), "hasMore": offset + limit < len(ordered), "syncComplete": self.sync_complete}

    def detail(self, uid: int) -> dict[str, Any]:
        with self.lock:
            if uid not in self.details:
                raise ValueError("Message analysis is not available yet.")
            return self.details[uid]

    def get_alerts(self) -> list[dict[str, Any]]:
        with self.lock:
            return sorted(self.alerts, key=lambda item: item["uid"], reverse=True)

    @staticmethod
    def _login(account: str, app_password: str) -> imaplib.IMAP4_SSL:
        client = imaplib.IMAP4_SSL("imap.gmail.com", 993, ssl_context=ssl.create_default_context(), timeout=20)
        client.login(account, app_password)
        status, _ = client.select("INBOX", readonly=True)
        if status != "OK":
            try:
                client.logout()
            finally:
                raise RuntimeError("Gmail INBOX could not be opened.")
        return client

    @staticmethod
    def _logout(client: imaplib.IMAP4_SSL) -> None:
        try:
            client.logout()
        except Exception:
            pass

    def connect(self, account: str, app_password: str) -> dict[str, Any]:
        self.disconnect()
        account = account.strip().lower()
        app_password = app_password.replace(" ", "")
        if not account.endswith("@gmail.com"):
            raise ValueError("Enter a Gmail address ending in @gmail.com.")
        if not app_password:
            raise ValueError("Enter the 16-character Google App Password.")
        client = self._login(account, app_password)
        try:
            status, data = client.uid("search", None, "ALL")
            if status != "OK":
                raise RuntimeError("Gmail messages could not be listed.")
            uids = [int(value) for value in (data[0] or b"").split() if value.isdigit()]
        finally:
            self._logout(client)
        with self.lock:
            self._generation += 1
            generation = self._generation
            self._stop = threading.Event()
            self.connected = True
            self.account = account
            self.status_message = "Connected — synchronizing INBOX"
            self.sync_total, self.sync_count, self.sync_complete = len(uids), 0, not uids
            self.last_uid = max(uids, default=0)
            self.messages.clear(); self.details.clear(); self.alerts.clear()
            self._thread = threading.Thread(target=self._sync_monitor, args=(account, app_password, list(reversed(uids)), generation, self._stop), daemon=True, name="mailtrace-gmail")
            self._thread.start()
        return self.snapshot()

    def disconnect(self) -> dict[str, Any]:
        with self.lock:
            self._generation += 1
            self._stop.set()
            thread = self._thread
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=2)
        with self.lock:
            self.connected = False; self.account = ""; self.status_message = "Not connected"
            self.sync_total = 0; self.sync_count = 0; self.sync_complete = False; self.last_uid = 0
            self.messages.clear(); self.details.clear(); self.alerts.clear(); self._thread = None
        return self.snapshot()

    def _fetch(self, client: imaplib.IMAP4_SSL, uid: int, historical: bool, generation: int) -> None:
        status, payload = client.uid("fetch", str(uid), "(BODY.PEEK[])")
        if status != "OK":
            return
        raw_bytes = next((item[1] for item in payload if isinstance(item, tuple) and isinstance(item[1], bytes)), None)
        if not raw_bytes:
            return
        raw = raw_bytes.decode("utf-8", errors="replace")
        analysis = self.engine.analyze(raw)
        summary = {
            "id": secrets.token_hex(8), "uid": uid, "subject": analysis["subject"], "from": analysis["senderDisplay"],
            "date": analysis["date"], "threatScore": analysis["threatScore"], "evidenceConfidence": analysis["evidenceConfidence"],
            "severity": analysis["severity"], "classification": analysis["classification"], "suspicious": analysis["threatScore"] >= 45,
            "historical": historical, "observedIp": (analysis.get("primaryObservedIp") or {}).get("ip", "Not available"),
            "device": analysis["device"]["inferred"], "routeHops": len(analysis["route"]),
        }
        with self.lock:
            if generation != self._generation:
                return
            self.messages.append(summary)
            self.details[uid] = analysis
            if summary["suspicious"]:
                self.alerts.append(summary)

    def _sync_monitor(self, account: str, app_password: str, uids: list[int], generation: int, stop: threading.Event) -> None:
        try:
            client = self._login(account, app_password)
            try:
                for uid in uids:
                    if stop.is_set() or generation != self._generation:
                        return
                    try:
                        self._fetch(client, uid, True, generation)
                    finally:
                        with self.lock:
                            self.sync_count += 1
                            self.status_message = f"Synchronizing INBOX — {self.sync_count} of {self.sync_total}"
            finally:
                self._logout(client)
            with self.lock:
                self.sync_complete = True
                self.status_message = f"INBOX synchronized — monitoring new mail ({len(self.messages)} messages)"
            while not stop.wait(20):
                self._poll(account, app_password, generation)
        except Exception as exc:
            with self.lock:
                if generation == self._generation:
                    self.connected = False
                    self.status_message = f"Gmail monitoring stopped safely: {type(exc).__name__}. Reconnect to continue."

    def _poll(self, account: str, app_password: str, generation: int) -> None:
        client = self._login(account, app_password)
        try:
            start = self.last_uid + 1
            status, data = client.uid("search", None, f"UID {start}:*")
            if status != "OK":
                raise RuntimeError("New Gmail messages could not be listed.")
            uids = [int(value) for value in (data[0] or b"").split() if value.isdigit() and int(value) >= start]
            for uid in sorted(uids):
                self._fetch(client, uid, False, generation)
                with self.lock:
                    self.last_uid = max(self.last_uid, uid)
            with self.lock:
                self.status_message = f"INBOX synchronized — monitoring new mail ({len(self.messages)} messages)"
        finally:
            self._logout(client)

    def save_case(self, uid: int, analyst: str, privacy_mode: bool) -> dict[str, Any]:
        analysis = self.detail(uid)
        return self.store.create_case(dict(analysis), analyst, privacy_mode)
