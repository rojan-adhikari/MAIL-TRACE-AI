"""Optional public-intelligence enrichment with safe local fallbacks."""

from __future__ import annotations

import ipaddress
import json
import os
import re
import socket
import threading
import time
from datetime import datetime, timezone
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


class EnrichmentUnavailable(RuntimeError):
    pass


class IntelligenceService:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.cache: dict[str, tuple[float, dict[str, Any]]] = {}

    def status(self) -> list[dict[str, Any]]:
        return [
            {"name": "IP geolocation / ASN", "provider": "ipapi.co keyless endpoint", "status": "AVAILABLE ON DEMAND", "keyRequired": False},
            {"name": "DNS A/AAAA", "provider": "Local system resolver", "status": "AVAILABLE ON DEMAND", "keyRequired": False},
            {"name": "RDAP", "provider": "rdap.org bootstrap proxy", "status": "AVAILABLE ON DEMAND", "keyRequired": False},
            {"name": "VirusTotal", "status": "CONFIGURED" if os.getenv("VIRUSTOTAL_API_KEY") else "NOT CONFIGURED", "keyRequired": True},
            {"name": "AbuseIPDB", "status": "CONFIGURED" if os.getenv("ABUSEIPDB_API_KEY") else "NOT CONFIGURED", "keyRequired": True},
            {"name": "AlienVault OTX", "status": "CONFIGURED" if os.getenv("OTX_API_KEY") else "NOT CONFIGURED", "keyRequired": True},
            {"name": "URLhaus", "status": "NOT CONFIGURED", "keyRequired": False},
            {"name": "PhishTank", "status": "NOT CONFIGURED", "keyRequired": True},
        ]

    def _cached(self, key: str) -> dict[str, Any] | None:
        with self.lock:
            entry = self.cache.get(key)
            return {**entry[1], "cached": True} if entry and time.time() - entry[0] < 3600 else None

    def _store(self, key: str, value: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            self.cache[key] = (time.time(), value)
        return value

    @staticmethod
    def _json_request(url: str) -> dict[str, Any]:
        request = Request(url, headers={"User-Agent": "MAILTRACE-AI/1.0 defensive-research"})
        try:
            with urlopen(request, timeout=10) as response:
                return json.loads(response.read(500_000).decode("utf-8"))
        except (HTTPError, URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
            raise EnrichmentUnavailable("External enrichment unavailable — local analysis continued.") from exc

    def lookup_ip(self, value: str) -> dict[str, Any]:
        try:
            ip = ipaddress.ip_address(value.strip())
        except ValueError as exc:
            raise ValueError("Enter a valid IPv4 or IPv6 address.") from exc
        if not ip.is_global:
            raise ValueError("Private, reserved and synthetic-demo IPs cannot be queried as live intelligence.")
        key = f"ip:{ip}"
        if cached := self._cached(key):
            return cached
        data = self._json_request(f"https://ipapi.co/{ip}/json/")
        if data.get("error"):
            raise EnrichmentUnavailable(str(data.get("reason") or "The provider returned no result."))
        organization = str(data.get("org") or "Unavailable")
        cloud = any(token in organization.lower() for token in ("amazon", "google", "microsoft", "azure", "cloudflare", "digitalocean", "linode", "vultr", "hetzner", "ovh", "hosting", "datacenter"))
        confidence = 72 + (4 if data.get("region") else 0) + (4 if data.get("city") else 0)
        return self._store(key, {
            "ip": str(ip), "country": data.get("country_name") or "Unavailable", "region": data.get("region") or "Unavailable",
            "city": data.get("city") or "Unavailable", "latitude": data.get("latitude"), "longitude": data.get("longitude"),
            "timezone": data.get("timezone") or "Unavailable", "asn": data.get("asn") or "Unavailable", "organization": organization,
            "cloudProvider": cloud, "vpn": "NOT ASSESSED", "proxy": "NOT ASSESSED", "tor": "NOT ASSESSED",
            "confidence": min(confidence, 80), "accuracy": "Approximate IP-database location; no accuracy radius supplied",
            "attribution": "NOT DETERMINED", "source": "ipapi.co on-demand lookup", "timestamp": datetime.now(timezone.utc).isoformat(),
            "synthetic": False, "cached": False, "disclaimer": "Geolocation represents probable network infrastructure, not the physical location of the sender.",
        })

    def lookup_domain(self, domain: str) -> dict[str, Any]:
        domain = domain.strip().lower().rstrip(".")
        if not domain or not all(re.fullmatch(r"[a-z0-9-]{1,63}", label) for label in domain.split(".")):
            raise ValueError("Enter a syntactically valid ASCII domain name.")
        key = f"domain:{domain}"
        if cached := self._cached(key):
            return cached
        addresses: list[str] = []
        dns_error = None
        try:
            addresses = sorted({item[4][0] for item in socket.getaddrinfo(domain, None, type=socket.SOCK_STREAM)})
        except OSError as exc:
            dns_error = type(exc).__name__
        rdap: dict[str, Any] = {}
        rdap_error = None
        try:
            rdap = self._json_request(f"https://rdap.org/domain/{quote(domain)}")
        except EnrichmentUnavailable as exc:
            rdap_error = str(exc)
        events = {item.get("eventAction"): item.get("eventDate") for item in rdap.get("events", []) if isinstance(item, dict)}
        nameservers = [item.get("ldhName") for item in rdap.get("nameservers", []) if item.get("ldhName")]
        registrar = "Registration information unavailable/redacted"
        for entity in rdap.get("entities", []):
            roles = entity.get("roles", [])
            if "registrar" in roles:
                vcard = entity.get("vcardArray", [None, []])
                for field in vcard[1] if len(vcard) > 1 else []:
                    if field and field[0] == "fn":
                        registrar = field[-1]
                        break
        return self._store(key, {
            "domain": domain, "addresses": addresses, "dnsStatus": "RESOLVED" if addresses else "FAILED/NO RECORD",
            "dnsError": dns_error, "registrationDate": events.get("registration") or "Unavailable/redacted",
            "lastChanged": events.get("last changed") or "Unavailable", "expirationDate": events.get("expiration") or "Unavailable",
            "registrar": registrar, "nameservers": nameservers, "rdapStatus": "AVAILABLE" if rdap else "UNAVAILABLE",
            "rdapError": rdap_error, "registrantAttribution": "NOT DETERMINED", "source": "System DNS resolver and public RDAP",
            "timestamp": datetime.now(timezone.utc).isoformat(), "cached": False,
            "disclaimer": "Registration and hosting data identify infrastructure records; they do not identify the attacker.",
        })


INTELLIGENCE = IntelligenceService()
