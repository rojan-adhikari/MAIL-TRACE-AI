"""Small deterministic TF-IDF logistic-regression model with measured metrics.

This model is trained at runtime on the bundled, clearly-labelled synthetic
dataset. It is decision support only and the forensic verdict never depends on
the model alone.
"""

from __future__ import annotations

import json
import math
import re
import time
from collections import Counter
from pathlib import Path
from typing import Any


TOKEN_RE = re.compile(r"[a-z0-9]+(?:'[a-z]+)?")


def tokenize(text: str) -> list[str]:
    words = TOKEN_RE.findall(text.lower())
    return words + [f"{left}_{right}" for left, right in zip(words, words[1:])]


class LightweightThreatModel:
    def __init__(self, dataset_path: Path) -> None:
        self.dataset = json.loads(dataset_path.read_text(encoding="utf-8"))
        self.vocabulary: dict[str, int] = {}
        self.idf: dict[str, float] = {}
        self.weights: list[float] = []
        self.bias = 0.0
        self.training_seconds = 0.0
        self._train()

    def _vector(self, text: str) -> dict[int, float]:
        counts = Counter(tokenize(text))
        total = max(sum(counts.values()), 1)
        vector: dict[int, float] = {}
        for token, count in counts.items():
            index = self.vocabulary.get(token)
            if index is not None:
                vector[index] = (count / total) * self.idf[token]
        length = math.sqrt(sum(value * value for value in vector.values())) or 1.0
        return {index: value / length for index, value in vector.items()}

    @staticmethod
    def _sigmoid(value: float) -> float:
        value = max(-35.0, min(35.0, value))
        return 1.0 / (1.0 + math.exp(-value))

    def _train(self) -> None:
        started = time.perf_counter()
        rows = [row for row in self.dataset if row["split"] == "train"]
        documents = [set(tokenize(row["text"])) for row in rows]
        document_frequency = Counter(token for document in documents for token in document)
        selected = sorted(token for token, count in document_frequency.items() if count >= 1)
        self.vocabulary = {token: index for index, token in enumerate(selected)}
        self.idf = {token: math.log((1 + len(rows)) / (1 + document_frequency[token])) + 1 for token in selected}
        self.weights = [0.0] * len(selected)
        vectors = [(self._vector(row["text"]), int(row["label"])) for row in rows]
        learning_rate = 0.45
        regularization = 0.015
        for _ in range(320):
            gradient = [0.0] * len(self.weights)
            bias_gradient = 0.0
            for vector, label in vectors:
                probability = self._sigmoid(self.bias + sum(self.weights[index] * value for index, value in vector.items()))
                error = probability - label
                bias_gradient += error
                for index, value in vector.items():
                    gradient[index] += error * value
            scale = 1 / max(len(vectors), 1)
            for index in range(len(self.weights)):
                self.weights[index] -= learning_rate * (gradient[index] * scale + regularization * self.weights[index])
            self.bias -= learning_rate * bias_gradient * scale
        self.training_seconds = time.perf_counter() - started

    def predict_probability(self, text: str) -> float:
        vector = self._vector(text)
        return self._sigmoid(self.bias + sum(self.weights[index] * value for index, value in vector.items()))

    @staticmethod
    def behavioral_probability(text: str) -> float:
        normalized = text.lower()
        groups = [
            r"urgent|immediately|within one hour|today only|without delay",
            r"beneficiary|wire transfer|bank account.{0,20}changed|gift cards?|invoice payment",
            r"password|credentials|verify.{0,20}account|mailbox.{0,20}(disabled|suspended)",
            r"keep.{0,20}(confidential|secret)|do not call|between us",
            r"ceo|chairman|director|registrar|finance head",
        ]
        matched = sum(bool(re.search(pattern, normalized)) for pattern in groups)
        return min(0.96, 0.18 + matched * 0.17)

    def hybrid_probability(self, text: str) -> float:
        model = self.predict_probability(text)
        behavior = self.behavioral_probability(text)
        return max(model * 0.78 + behavior * 0.22, behavior if behavior >= 0.69 else 0.0)

    @staticmethod
    def _metrics(labels: list[int], predictions: list[int]) -> dict[str, float | int]:
        tp = sum(a == 1 and b == 1 for a, b in zip(labels, predictions))
        tn = sum(a == 0 and b == 0 for a, b in zip(labels, predictions))
        fp = sum(a == 0 and b == 1 for a, b in zip(labels, predictions))
        fn = sum(a == 1 and b == 0 for a, b in zip(labels, predictions))
        accuracy = (tp + tn) / max(len(labels), 1)
        precision = tp / max(tp + fp, 1)
        recall = tp / max(tp + fn, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-9)
        return {
            "accuracy": round(accuracy * 100, 2), "precision": round(precision * 100, 2),
            "recall": round(recall * 100, 2), "f1": round(f1 * 100, 2),
            "falsePositiveRate": round(fp / max(fp + tn, 1) * 100, 2),
            "falseNegativeRate": round(fn / max(fn + tp, 1) * 100, 2),
            "tp": tp, "tn": tn, "fp": fp, "fn": fn, "samples": len(labels),
        }

    def benchmark(self) -> dict[str, Any]:
        test = [row for row in self.dataset if row["split"] == "test"]
        labels = [int(row["label"]) for row in test]
        started = time.perf_counter()
        baseline_scores = [self.predict_probability(row["text"]) for row in test]
        baseline_time = (time.perf_counter() - started) * 1000
        started = time.perf_counter()
        hybrid_scores = [self.hybrid_probability(row["text"]) for row in test]
        hybrid_time = (time.perf_counter() - started) * 1000
        adversarial_texts = [self.safe_variations(row["text"])[1] for row in test]
        adversarial_predictions = [int(self.hybrid_probability(text) >= 0.5) for text in adversarial_texts]
        original_predictions = [int(score >= 0.5) for score in hybrid_scores]
        stable = sum(a == b for a, b in zip(original_predictions, adversarial_predictions))
        return {
            "dataset": {"type": "Curated synthetic demonstration dataset", "train": sum(row["split"] == "train" for row in self.dataset), "validation": sum(row["split"] == "validation" for row in self.dataset), "test": len(test)},
            "baseline": {**self._metrics(labels, [int(score >= 0.5) for score in baseline_scores]), "averageAnalysisMs": round(baseline_time / max(len(test), 1), 3), "model": "Runtime TF-IDF + logistic regression"},
            "transformer": {"status": "NOT CONFIGURED", "reason": "Offline lightweight mode; no transformer metrics are fabricated."},
            "hybrid": {**self._metrics(labels, original_predictions), "averageAnalysisMs": round(hybrid_time / max(len(test), 1), 3), "model": "Evidence-aware hybrid"},
            "adversarialStability": round(stable / max(len(test), 1) * 100, 2),
            "evaluatedAtRuntime": True,
            "limitations": "The bundled dataset is intentionally small and synthetic; metrics demonstrate reproducibility, not production accuracy.",
        }

    @staticmethod
    def safe_variations(text: str) -> list[str]:
        return [
            text,
            "Hope your week is going well. " + text,
            re.sub(r"urgent", "u r g e n t", text, flags=re.IGNORECASE),
            re.sub(r"[.!?]", " ", text),
            re.sub(r"immediately", "without unnecessary delay", text, flags=re.IGNORECASE),
        ]

    def evasion_check(self, text: str) -> dict[str, Any]:
        variations = self.safe_variations(text)
        scores = [round(self.hybrid_probability(value) * 100) for value in variations]
        spread = max(scores) - min(scores)
        stability = "HIGH" if spread <= 12 else "MEDIUM" if spread <= 25 else "LOW"
        return {
            "originalScore": scores[0], "modifiedScores": scores[1:], "minimumScore": min(scores),
            "maximumScore": max(scores), "spread": spread, "detectionStability": stability,
            "variations": ["Benign prefix", "Whitespace insertion", "Punctuation removal", "Safe paraphrase"],
            "safeSyntheticTest": True,
        }
