"""Dependency-free PDF forensic report generator."""

from __future__ import annotations

import textwrap
from typing import Any


def _safe(value: Any) -> str:
    text = str(value).encode("latin-1", errors="replace").decode("latin-1")
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _lines(case: dict[str, Any]) -> list[tuple[str, str]]:
    analysis = case["analysis"]
    geo = analysis.get("geolocation") or {}
    rows: list[tuple[str, str]] = [
        ("title", "MAILTRACE AI - FORENSIC INVESTIGATION REPORT"),
        ("meta", f"Case: {case['case_id']} | Status: {case['status']} | Analyst: {case['analyst']}"),
        ("meta", f"Generated from evidence stored at {case['created_at']} | Synthetic: {case['synthetic']}"),
        ("section", "1. EXECUTIVE SUMMARY"),
        ("body", analysis["conclusion"]),
        ("section", "2. EMAIL METADATA"),
        ("body", f"Subject: {analysis['subject']}"), ("body", f"From: {analysis['senderDisplay']}"),
        ("body", f"Reply-To: {analysis['replyTo']}"), ("body", f"Return-Path: {analysis['returnPath']}"),
        ("body", f"Message-ID: {analysis['messageId']}"), ("body", f"Date: {analysis['date']}"),
        ("section", "3. THREAT VERDICT"),
        ("body", f"Severity: {analysis['severity']} | Classification: {analysis['classification']}"),
        ("body", f"Threat score: {analysis['threatScore']}/100 | Evidence confidence: {analysis['evidenceConfidence']}/100"),
        ("section", "4. AUTHENTICATION ANALYSIS"),
    ]
    for method, value in analysis.get("authentication", {}).items():
        rows.append(("body", f"{method}: {value['result']} | Confidence {value['confidence']}% | {value['source']}"))
    rows.append(("section", "5. HEADER FORENSICS AND RELAY PATH"))
    for hop in analysis.get("route", []):
        ips = ", ".join(f"{item['ip']} [{item['scope']}]" for item in hop["ips"]) or "No IP disclosed"
        rows.append(("body", f"Hop {hop['hop']}: {hop['fromHostname']} -> {hop['byHostname']} | {ips} | {hop['timestamp']} | Trust {hop['trustLevel']} {hop['trustConfidence']}%"))
    if not analysis.get("route"):
        rows.append(("uncertainty", "UNCERTAINTY: No Received headers were supplied."))
    rows.extend([
        ("section", "6. IP AND GEOLOCATION INTELLIGENCE"),
        ("body", f"Observed IP: {(analysis.get('primaryObservedIp') or {}).get('ip', 'Not available')}"),
        ("body", f"Probable infrastructure: {geo.get('organization', 'Not available')} | ASN {geo.get('asn', 'Not available')}"),
        ("body", f"Probable location: {geo.get('city', 'Not available')}, {geo.get('region', 'Not available')}, {geo.get('country', 'Not available')} | Confidence {geo.get('confidence', 0)}%"),
        ("uncertainty", "Geolocation represents network infrastructure, not necessarily the physical location of the sender."),
        ("section", "7. DOMAIN AND URL INTELLIGENCE"),
        ("body", f"Sender domain: {analysis['senderDomain']} | TLD risk: {analysis['domainIntelligence']['tldRisk']} | IDN/Punycode: {analysis['domainIntelligence']['idnPunycode']}"),
    ])
    for item in analysis.get("urls", []):
        rows.append(("body", f"URL: {item['url']} | Flags: {', '.join(item['flags']) or 'No local flags'} | Reputation: {item['reputation']}"))
    rows.append(("section", "8. BEC AND AI ANALYSIS"))
    rows.append(("body", f"BEC categories: {', '.join(analysis.get('becTypes', [])) or 'None detected'}"))
    rows.append(("body", f"Runtime model: {analysis['ml']['model']} | Hybrid probability: {analysis['ml']['hybridProbability']}% | Evasion stability: {analysis['evasionCheck']['detectionStability']}"))
    rows.append(("section", "9. ATTACHMENT INDICATORS"))
    if analysis.get("attachments"):
        for item in analysis["attachments"]:
            rows.append(("body", f"{item['filename']} | SHA-256: {item['sha256']} | Dangerous extension: {item['dangerousExtension']} | Executed: False"))
    else:
        rows.append(("body", "No attachment bytes or attachment-name indicators were supplied."))
    rows.extend([
        ("section", "10. THREAT INFRASTRUCTURE GRAPH"),
        ("body", f"Graph contains {len(analysis['graph']['nodes'])} nodes and {len(analysis['graph']['edges'])} relationships."),
    ])
    for edge in analysis["graph"]["edges"][:30]:
        rows.append(("body", f"{edge['source']} --{edge['type']}--> {edge['target']}"))
    rows.append(("section", "11. CAMPAIGN CORRELATION"))
    correlation = analysis.get("campaignCorrelation", {})
    rows.append(("body", f"Campaign: {correlation.get('campaignId') or 'No correlated campaign'} | Match score: {correlation.get('score', 0)} | Shared indicators: {len(correlation.get('shared', []))}"))
    rows.append(("section", "12. INDICATORS OF COMPROMISE"))
    for item in analysis.get("indicators", []):
        rows.append(("body", f"{item['type']}: {item['value']} | Confidence {item['confidence']}%"))
    rows.append(("section", "13. EVIDENCE HASHES AND CHAIN OF CUSTODY"))
    rows.append(("body", f"Normalized email SHA-256: {analysis['sha256']}"))
    rows.append(("body", f"Ledger verification: {'VALID' if case.get('ledgerVerified') else 'FAILED'} | Entries: {len(case.get('ledger', []))}"))
    for item in case.get("ledger", [])[:25]:
        rows.append(("body", f"{item['evidence_id']} | Evidence {item['evidence_hash']} | Chain {item['chain_hash']}"))
    rows.append(("section", "14. FACT, INFERENCE AND UNCERTAINTY"))
    for item in analysis.get("evidence", []):
        rows.append((item["status"].lower(), f"{item['status']}: {item['title']} | {item['confidence']}% | {item['explanation']}"))
    rows.append(("section", "15. ANALYST CONCLUSION"))
    rows.append(("body", analysis["conclusion"]))
    rows.append(("section", "16. LIMITATIONS"))
    for item in analysis.get("limitations", []):
        rows.append(("uncertainty", item))
    return rows


def generate_pdf(case: dict[str, Any]) -> bytes:
    wrapped: list[tuple[str, str]] = []
    for style, value in _lines(case):
        width = 80 if style in {"title", "section"} else 96
        parts = textwrap.wrap(str(value), width=width, break_long_words=True, replace_whitespace=True) or [""]
        wrapped.extend((style, part) for part in parts)
        if style in {"title", "section"}:
            wrapped.append(("space", ""))
    pages: list[list[tuple[str, str]]] = []
    current: list[tuple[str, str]] = []
    used = 0
    for item in wrapped:
        height = 2 if item[0] in {"title", "section"} else 1
        if used + height > 49:
            pages.append(current)
            current, used = [], 0
        current.append(item)
        used += height
    if current:
        pages.append(current)

    objects: list[bytes] = []
    page_object_ids = [5 + index * 2 for index in range(len(pages))]
    objects.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    kids = " ".join(f"{value} 0 R" for value in page_object_ids)
    objects.append(f"<< /Type /Pages /Count {len(pages)} /Kids [{kids}] >>".encode())
    objects.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    objects.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>")
    for page_index, page in enumerate(pages, start=1):
        content_id = 6 + (page_index - 1) * 2
        objects.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {content_id} 0 R >>".encode())
        commands = ["0.04 0.08 0.11 rg 0 806 595 36 re f", "0.18 0.75 0.84 rg BT /F2 9 Tf 45 820 Td (MAILTRACE AI / EVIDENCE-DRIVEN FORENSIC REPORT) Tj ET"]
        y = 785
        for style, text in page:
            if style == "space":
                y -= 5
                continue
            font = "F2" if style in {"title", "section"} else "F1"
            size = 15 if style == "title" else 11 if style == "section" else 8
            color = "0.05 0.48 0.58" if style in {"title", "section"} else "0.72 0.77 0.80" if style == "uncertainty" else "0.12 0.16 0.18"
            commands.append(f"{color} rg BT /{font} {size} Tf 45 {y} Td ({_safe(text)}) Tj ET")
            y -= 18 if style in {"title", "section"} else 13
        commands.append(f"0.35 0.40 0.43 rg BT /F1 7 Tf 45 24 Td (Page {page_index} of {len(pages)} - Generated locally - attribution limitations apply) Tj ET")
        stream = "\n".join(commands).encode("latin-1")
        objects.append(b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream")

    pdf = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for index, content in enumerate(objects, start=1):
        offsets.append(len(pdf))
        pdf.extend(f"{index} 0 obj\n".encode())
        pdf.extend(content)
        pdf.extend(b"\nendobj\n")
    xref = len(pdf)
    pdf.extend(f"xref\n0 {len(objects)+1}\n".encode())
    pdf.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        pdf.extend(f"{offset:010d} 00000 n \n".encode())
    pdf.extend(f"trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF".encode())
    return bytes(pdf)
