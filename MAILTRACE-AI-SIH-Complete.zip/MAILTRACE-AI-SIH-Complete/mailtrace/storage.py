"""SQLite case management, campaign correlation, audit log and evidence ledger."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class CaseStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.lock = threading.RLock()
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    def _initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.executescript("""
                CREATE TABLE IF NOT EXISTS cases (
                    case_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                    analyst TEXT NOT NULL, status TEXT NOT NULL, severity TEXT NOT NULL,
                    classification TEXT NOT NULL, threat_score INTEGER NOT NULL,
                    evidence_confidence INTEGER NOT NULL, subject TEXT NOT NULL, sender TEXT NOT NULL,
                    synthetic INTEGER NOT NULL DEFAULT 0, privacy_mode INTEGER NOT NULL DEFAULT 0,
                    campaign_id TEXT, analysis_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, case_id TEXT NOT NULL, analyst TEXT NOT NULL,
                    note TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(case_id) REFERENCES cases(case_id)
                );
                CREATE TABLE IF NOT EXISTS decisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, case_id TEXT NOT NULL, analyst TEXT NOT NULL,
                    decision TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(case_id) REFERENCES cases(case_id)
                );
                CREATE TABLE IF NOT EXISTS ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, case_id TEXT NOT NULL, evidence_id TEXT NOT NULL,
                    evidence_hash TEXT NOT NULL, previous_hash TEXT NOT NULL, chain_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL, FOREIGN KEY(case_id) REFERENCES cases(case_id)
                );
                CREATE TABLE IF NOT EXISTS campaigns (
                    campaign_id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL, risk TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, case_id TEXT,
                    analyst TEXT NOT NULL, created_at TEXT NOT NULL, details TEXT NOT NULL
                );
            """)

    @staticmethod
    def _indicator_map(analysis: dict[str, Any]) -> dict[tuple[str, str], int]:
        weights = {"ATTACHMENT_SHA256": 6, "IP": 4, "ASN": 4, "URL": 3, "DOMAIN": 2, "PROVIDER": 2}
        return {(item["type"], item["value"]): weights.get(item["type"], 1) for item in analysis.get("indicators", []) if item.get("value") not in {"unknown", "Not available"}}

    def _next_id(self, connection: sqlite3.Connection, prefix: str, table: str) -> str:
        year = datetime.now().year
        count = connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] + 1
        return f"{prefix}-{year}-{count:05d}"

    def _correlate(self, connection: sqlite3.Connection, analysis: dict[str, Any], new_case_id: str) -> tuple[str | None, dict[str, Any]]:
        current = self._indicator_map(analysis)
        best_case: sqlite3.Row | None = None
        best_score = 0
        best_shared: list[dict[str, Any]] = []
        for row in connection.execute("SELECT case_id, campaign_id, analysis_json FROM cases ORDER BY created_at DESC LIMIT 250"):
            other = self._indicator_map(json.loads(row["analysis_json"]))
            shared = current.keys() & other.keys()
            score = sum(max(current[item], other[item]) for item in shared)
            if score > best_score:
                best_case, best_score = row, score
                best_shared = [{"type": item[0], "value": item[1]} for item in sorted(shared)]
        if best_score < 4 or best_case is None:
            return None, {"matched": False, "score": best_score, "shared": best_shared}
        campaign_id = best_case["campaign_id"]
        now = utc_now()
        if not campaign_id:
            campaign_id = self._next_id(connection, "CAMP", "campaigns")
            connection.execute("INSERT INTO campaigns VALUES (?,?,?,?,?)", (campaign_id, f"Correlated infrastructure cluster {campaign_id[-5:]}", now, now, analysis["severity"]))
            connection.execute("UPDATE cases SET campaign_id=?, updated_at=? WHERE case_id=?", (campaign_id, now, best_case["case_id"]))
        else:
            connection.execute("UPDATE campaigns SET updated_at=?, risk=? WHERE campaign_id=?", (now, analysis["severity"], campaign_id))
        analysis["graph"]["nodes"].append({"id": f"campaign:{campaign_id}", "type": "Campaign", "label": campaign_id})
        analysis["graph"]["edges"].append({"source": analysis["analysisId"], "target": f"campaign:{campaign_id}", "type": "SEEN_IN_CAMPAIGN"})
        return campaign_id, {"matched": True, "score": best_score, "shared": best_shared, "relatedCase": best_case["case_id"]}

    def create_case(self, analysis: dict[str, Any], analyst: str = "Rozan Adhikari", privacy_mode: bool = False) -> dict[str, Any]:
        with self.lock, self._connect() as connection:
            case_id = self._next_id(connection, "CASE", "cases")
            now = utc_now()
            campaign_id, correlation = self._correlate(connection, analysis, case_id)
            analysis["campaignCorrelation"] = {**correlation, "campaignId": campaign_id, "relatedCampaigns": 1 if campaign_id else 0}
            connection.execute(
                "INSERT INTO cases VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (case_id, now, now, analyst, "UNDER INVESTIGATION", analysis["severity"], analysis["classification"], analysis["threatScore"], analysis["evidenceConfidence"], analysis["subject"], analysis["sender"], int(analysis.get("synthetic", False)), int(privacy_mode), campaign_id, json.dumps(analysis, ensure_ascii=False)),
            )
            previous = "0" * 64
            for item in analysis.get("evidence", []):
                normalized = json.dumps(item, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
                evidence_hash = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
                created = item.get("timestamp", now)
                chain_hash = hashlib.sha256(f"{previous}|{evidence_hash}|{created}".encode("utf-8")).hexdigest()
                connection.execute("INSERT INTO ledger(case_id,evidence_id,evidence_hash,previous_hash,chain_hash,created_at) VALUES (?,?,?,?,?,?)", (case_id, item["id"], evidence_hash, previous, chain_hash, created))
                previous = chain_hash
            connection.execute("INSERT INTO audit_log(action,case_id,analyst,created_at,details) VALUES (?,?,?,?,?)", ("CASE_CREATED", case_id, analyst, now, json.dumps({"synthetic": analysis.get("synthetic", False), "privacyMode": privacy_mode})))
        return self.get_case(case_id)

    def list_cases(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute("SELECT case_id,created_at,updated_at,analyst,status,severity,classification,threat_score,evidence_confidence,subject,sender,synthetic,campaign_id FROM cases ORDER BY created_at DESC LIMIT ?", (max(1, min(limit, 500)),)).fetchall()
        return [{**dict(row), "synthetic": bool(row["synthetic"])} for row in rows]

    def get_case(self, case_id: str) -> dict[str, Any]:
        with self._connect() as connection:
            row = connection.execute("SELECT * FROM cases WHERE case_id=?", (case_id,)).fetchone()
            if not row:
                raise ValueError("Case not found.")
            notes = [dict(value) for value in connection.execute("SELECT analyst,note,created_at FROM notes WHERE case_id=? ORDER BY id", (case_id,))]
            decisions = [dict(value) for value in connection.execute("SELECT analyst,decision,created_at FROM decisions WHERE case_id=? ORDER BY id", (case_id,))]
            ledger = [dict(value) for value in connection.execute("SELECT evidence_id,evidence_hash,previous_hash,chain_hash,created_at FROM ledger WHERE case_id=? ORDER BY id", (case_id,))]
        result = dict(row)
        result["analysis"] = json.loads(result.pop("analysis_json"))
        result["synthetic"] = bool(result["synthetic"])
        result["privacy_mode"] = bool(result["privacy_mode"])
        result["notes"], result["decisions"], result["ledger"] = notes, decisions, ledger
        result["ledgerVerified"] = self.verify_ledger(ledger)
        return result

    @staticmethod
    def verify_ledger(entries: list[dict[str, Any]]) -> bool:
        previous = "0" * 64
        for item in entries:
            if item["previous_hash"] != previous:
                return False
            expected = hashlib.sha256(f"{previous}|{item['evidence_hash']}|{item['created_at']}".encode("utf-8")).hexdigest()
            if expected != item["chain_hash"]:
                return False
            previous = item["chain_hash"]
        return True

    def add_note(self, case_id: str, note: str, analyst: str) -> dict[str, Any]:
        if not note.strip():
            raise ValueError("Enter a note before saving.")
        now = utc_now()
        with self.lock, self._connect() as connection:
            if not connection.execute("SELECT 1 FROM cases WHERE case_id=?", (case_id,)).fetchone():
                raise ValueError("Case not found.")
            connection.execute("INSERT INTO notes(case_id,analyst,note,created_at) VALUES (?,?,?,?)", (case_id, analyst, note.strip()[:5000], now))
            connection.execute("UPDATE cases SET updated_at=? WHERE case_id=?", (now, case_id))
            connection.execute("INSERT INTO audit_log(action,case_id,analyst,created_at,details) VALUES (?,?,?,?,?)", ("NOTE_ADDED", case_id, analyst, now, "{}"))
        return self.get_case(case_id)

    def decision(self, case_id: str, decision: str, analyst: str) -> dict[str, Any]:
        allowed = {"CONFIRM THREAT", "MARK FALSE POSITIVE", "ESCALATE", "ADD TO CAMPAIGN", "DISMISS", "CLOSE CASE"}
        if decision not in allowed:
            raise ValueError("Unsupported analyst decision.")
        status = "CLOSED" if decision in {"DISMISS", "CLOSE CASE", "MARK FALSE POSITIVE"} else "ESCALATED" if decision == "ESCALATE" else "UNDER INVESTIGATION"
        now = utc_now()
        with self.lock, self._connect() as connection:
            if not connection.execute("SELECT 1 FROM cases WHERE case_id=?", (case_id,)).fetchone():
                raise ValueError("Case not found.")
            connection.execute("INSERT INTO decisions(case_id,analyst,decision,created_at) VALUES (?,?,?,?)", (case_id, analyst, decision, now))
            connection.execute("UPDATE cases SET status=?,updated_at=? WHERE case_id=?", (status, now, case_id))
            connection.execute("INSERT INTO audit_log(action,case_id,analyst,created_at,details) VALUES (?,?,?,?,?)", ("ANALYST_DECISION", case_id, analyst, now, json.dumps({"decision": decision})))
        return self.get_case(case_id)

    def campaigns(self) -> list[dict[str, Any]]:
        with self._connect() as connection:
            rows = connection.execute("""SELECT p.campaign_id,p.name,p.created_at,p.updated_at,p.risk,COUNT(c.case_id) email_count,COUNT(DISTINCT c.sender) sender_count FROM campaigns p LEFT JOIN cases c ON c.campaign_id=p.campaign_id GROUP BY p.campaign_id ORDER BY p.updated_at DESC""").fetchall()
            result = []
            for row in rows:
                cases = [dict(value) for value in connection.execute("SELECT case_id,subject,severity,classification FROM cases WHERE campaign_id=? ORDER BY created_at", (row["campaign_id"],))]
                result.append({**dict(row), "cases": cases})
        return result

    def dashboard(self) -> dict[str, Any]:
        with self._connect() as connection:
            total = connection.execute("SELECT COUNT(*) FROM cases").fetchone()[0]
            active = connection.execute("SELECT COUNT(*) FROM cases WHERE status!='CLOSED'").fetchone()[0]
            critical = connection.execute("SELECT COUNT(*) FROM cases WHERE severity='CRITICAL'").fetchone()[0]
            campaigns = connection.execute("SELECT COUNT(*) FROM campaigns").fetchone()[0]
            synthetic = connection.execute("SELECT COUNT(*) FROM cases WHERE synthetic=1").fetchone()[0]
            categories = [dict(value) for value in connection.execute("SELECT classification name,COUNT(*) value FROM cases GROUP BY classification ORDER BY value DESC")]
            organizations = Counter()
            for value in connection.execute("SELECT analysis_json FROM cases"):
                geolocation = (json.loads(value["analysis_json"]).get("geolocation") or {})
                if geolocation.get("organization"):
                    organizations[str(geolocation["organization"])] += 1
            infrastructure = [{"name": name, "value": count} for name, count in organizations.most_common(8)]
            recent = [dict(value) for value in connection.execute("SELECT case_id,subject,severity,classification,threat_score,created_at FROM cases ORDER BY created_at DESC LIMIT 8")]
        return {"activeCases": active, "criticalThreats": critical, "emailsAnalyzed": total, "campaignsDetected": campaigns, "syntheticCases": synthetic, "categories": categories, "infrastructure": infrastructure, "recent": recent, "dataNotice": "Dashboard includes clearly labelled synthetic demonstration cases."}
