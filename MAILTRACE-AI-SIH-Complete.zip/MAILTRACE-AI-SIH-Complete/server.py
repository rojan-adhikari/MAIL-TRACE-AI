"""MAILTRACE AI SIH prototype — local API gateway and web server."""

from __future__ import annotations

import copy
import imaplib
import json
import mimetypes
import os
import re
import ssl
import threading
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from mailtrace.forensics import InvestigationEngine
from mailtrace.gmail import GmailMonitor
from mailtrace.intelligence import INTELLIGENCE, EnrichmentUnavailable
from mailtrace.model import LightweightThreatModel
from mailtrace.report import generate_pdf
from mailtrace.storage import CaseStore


ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"
DATA = ROOT / "data"
HOST, PORT = os.getenv("MAILTRACE_HOST", "127.0.0.1"), 8788
MAX_BODY = 2_500_000

DEMOS = json.loads((DATA / "demos.json").read_text(encoding="utf-8"))
DEMO_BY_ID = {item["id"]: item for item in DEMOS}
MODEL = LightweightThreatModel(DATA / "dataset.json")
ENGINE = InvestigationEngine(MODEL)
STORE = CaseStore(DATA / "mailtrace.db")
GMAIL = GmailMonitor(ENGINE, STORE)


def mask_email(value: str) -> str:
    def replace(match: re.Match[str]) -> str:
        local, domain = match.group(1), match.group(2)
        return f"{local[:1]}***@{domain}"
    return re.sub(r"([A-Za-z0-9._%+-]+)@([A-Za-z0-9.-]+\.[A-Za-z]{2,})", replace, value)


def privacy_copy(analysis: dict[str, Any]) -> dict[str, Any]:
    masked = copy.deepcopy(analysis)
    for key in ("sender", "senderDisplay", "replyTo", "returnPath"):
        masked[key] = mask_email(str(masked.get(key, "")))
    for node in masked.get("graph", {}).get("nodes", []):
        node["label"] = mask_email(str(node.get("label", "")))
    masked["privacyMode"] = True
    return masked


def seed_synthetic_cases() -> None:
    if sum(item["synthetic"] for item in STORE.list_cases(500)) >= len(DEMOS):
        return
    for demo in DEMOS:
        analysis = ENGINE.analyze(demo["raw"], fixture=demo["fixture"], synthetic=True)
        STORE.create_case(analysis, analyst="Synthetic Demo Seeder", privacy_mode=False)


seed_synthetic_cases()


class Handler(BaseHTTPRequestHandler):
    server_version = "MAILTRACE-SIH/1.0"

    def log_message(self, format_string: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {format_string % args}")

    def json_response(self, payload: Any, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length < 1 or length > MAX_BODY:
            raise ValueError("Invalid request size.")
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self) -> None:
        try:
            parsed = urlparse(self.path)
            query = parse_qs(parsed.query)
            if parsed.path == "/api/health":
                self.json_response({"status": "ok", "product": "MAILTRACE AI", "version": "1.1.0", "offlineCore": True})
                return
            if parsed.path == "/api/demos":
                self.json_response({"synthetic": True, "demos": [{key: item[key] for key in ("id", "name", "severity", "description")} for item in DEMOS]})
                return
            if parsed.path == "/api/dashboard":
                self.json_response(STORE.dashboard()); return
            if parsed.path == "/api/benchmark":
                self.json_response(MODEL.benchmark()); return
            if parsed.path == "/api/integrations":
                self.json_response({"integrations": INTELLIGENCE.status(), "keysStoredInFrontend": False}); return
            if parsed.path == "/api/cases":
                self.json_response({"cases": STORE.list_cases(int(query.get("limit", [100])[0]))}); return
            if parsed.path == "/api/case":
                self.json_response(STORE.get_case(query.get("id", [""])[0])); return
            if parsed.path == "/api/campaigns":
                self.json_response({"campaigns": STORE.campaigns(), "syntheticDataIncluded": True}); return
            if parsed.path == "/api/report":
                case = STORE.get_case(query.get("caseId", [""])[0])
                body = generate_pdf(case)
                self.send_response(200)
                self.send_header("Content-Type", "application/pdf")
                self.send_header("Content-Disposition", f"attachment; filename={case['case_id']}-forensic-report.pdf")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers(); self.wfile.write(body); return
            if parsed.path == "/api/gmail/status":
                self.json_response(GMAIL.snapshot()); return
            if parsed.path == "/api/gmail/messages":
                self.json_response(GMAIL.page(int(query.get("offset", [0])[0]), int(query.get("limit", [50])[0]))); return
            if parsed.path == "/api/gmail/message":
                self.json_response(GMAIL.detail(int(query.get("uid", [""])[0]))); return
            if parsed.path == "/api/gmail/alerts":
                self.json_response({"alerts": GMAIL.get_alerts()}); return
            relative = "index.html" if parsed.path == "/" else parsed.path.lstrip("/")
            file_path = (WEB / relative).resolve()
            if WEB not in file_path.parents and file_path != WEB or not file_path.is_file() or file_path.name.startswith("."):
                self.send_error(HTTPStatus.NOT_FOUND); return
            body = file_path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(file_path.name)[0] or "application/octet-stream")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers(); self.wfile.write(body)
        except ValueError as exc:
            self.json_response({"error": str(exc)}, 400)
        except Exception as exc:
            self.json_response({"error": f"Request failed safely: {type(exc).__name__}"}, 500)

    def do_POST(self) -> None:
        try:
            payload = self.read_json()
            path = urlparse(self.path).path
            if path == "/api/investigate":
                demo_id = str(payload.get("demoId", ""))
                if demo_id:
                    demo = DEMO_BY_ID.get(demo_id)
                    if not demo:
                        raise ValueError("Unknown demonstration scenario.")
                    analysis = ENGINE.analyze(demo["raw"], fixture=demo["fixture"], synthetic=True)
                else:
                    analysis = ENGINE.analyze(str(payload.get("raw", "")))
                privacy_mode = bool(payload.get("privacyMode", False))
                if privacy_mode:
                    analysis = privacy_copy(analysis)
                result: dict[str, Any] = {"analysis": analysis}
                if payload.get("saveCase"):
                    result["case"] = STORE.create_case(analysis, str(payload.get("analyst") or "Rozan Adhikari"), privacy_mode)
                self.json_response(result); return
            if path == "/api/case/note":
                self.json_response(STORE.add_note(str(payload.get("caseId", "")), str(payload.get("note", "")), str(payload.get("analyst") or "Rozan Adhikari"))); return
            if path == "/api/case/decision":
                self.json_response(STORE.decision(str(payload.get("caseId", "")), str(payload.get("decision", "")), str(payload.get("analyst") or "Rozan Adhikari"))); return
            if path == "/api/enrich/ip":
                self.json_response(INTELLIGENCE.lookup_ip(str(payload.get("ip", "")))); return
            if path == "/api/enrich/domain":
                self.json_response(INTELLIGENCE.lookup_domain(str(payload.get("domain", "")))); return
            if path == "/api/gmail/connect":
                self.json_response(GMAIL.connect(str(payload.get("email", "")), str(payload.get("appPassword", "")))); return
            if path == "/api/gmail/disconnect":
                self.json_response(GMAIL.disconnect()); return
            if path == "/api/gmail/save-case":
                self.json_response(GMAIL.save_case(int(payload.get("uid")), str(payload.get("analyst") or "Rozan Adhikari"), bool(payload.get("privacyMode", False)))); return
            self.json_response({"error": "Unknown endpoint."}, 404)
        except (ValueError, json.JSONDecodeError) as exc:
            self.json_response({"error": str(exc)}, 400)
        except imaplib.IMAP4.error:
            self.json_response({"error": "Gmail login failed. Use the generated Google App Password, not the normal Gmail password."}, 401)
        except ssl.SSLCertVerificationError:
            self.json_response({"error": "Python cannot verify the certificate. On macOS open Applications → Python 3.x → Install Certificates.command, then restart MAILTRACE."}, 502)
        except EnrichmentUnavailable as exc:
            self.json_response({"error": str(exc), "fallback": "Local analysis continued."}, 502)
        except (ssl.SSLError, OSError, RuntimeError) as exc:
            self.json_response({"error": f"External connection failed safely: {exc}"}, 502)
        except Exception as exc:
            self.json_response({"error": f"Request failed safely: {type(exc).__name__}"}, 500)


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"MAILTRACE AI SIH prototype is running at http://{HOST}:{PORT}")
    print("Core analysis is offline-first. Gmail credentials remain only in process memory.")
    threading.Timer(0.8, lambda: webbrowser.open(f"http://{HOST}:{PORT}")).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        GMAIL.disconnect(); server.server_close()


if __name__ == "__main__":
    main()
