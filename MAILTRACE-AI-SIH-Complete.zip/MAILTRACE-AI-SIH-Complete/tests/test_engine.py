import json
import unittest
from pathlib import Path

from mailtrace.forensics import InvestigationEngine
from mailtrace.model import LightweightThreatModel


ROOT = Path(__file__).resolve().parents[1]


class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model = LightweightThreatModel(ROOT / "data" / "dataset.json")
        cls.engine = InvestigationEngine(cls.model)
        cls.demos = {item["id"]: item for item in json.loads((ROOT / "data" / "demos.json").read_text())}

    def analyze_demo(self, demo_id):
        demo = self.demos[demo_id]
        return self.engine.analyze(demo["raw"], demo["fixture"], True)

    def test_five_demo_scenarios_are_distinct(self):
        results = {key: self.analyze_demo(key) for key in self.demos}
        self.assertEqual(results["demo-legitimate"]["severity"], "LOW")
        self.assertEqual(results["demo-lookalike"]["severity"], "CRITICAL")
        self.assertEqual(results["demo-ceo-bec"]["severity"], "CRITICAL")
        self.assertEqual(results["demo-invoice"]["severity"], "CRITICAL")
        self.assertEqual(results["demo-credential"]["severity"], "HIGH")
        self.assertTrue(all(result["synthetic"] for result in results.values()))

    def test_lookalike_and_credential_evidence(self):
        result = self.analyze_demo("demo-lookalike")
        types = {item["evidence_type"] for item in result["evidence"]}
        self.assertIn("DOMAIN_SIMILARITY", types)
        self.assertIn("BEC_CREDENTIAL", types)
        self.assertIn("Lookalike-domain", result["classification"])

    def test_route_boundary_and_location_are_not_attribution(self):
        result = self.analyze_demo("demo-ceo-bec")
        self.assertTrue(any(hop["trustLevel"] == "GREEN" for hop in result["route"]))
        self.assertEqual(result["geolocation"]["attribution"], "NOT DETERMINED")
        self.assertIn("Exact physical location of the sender", result["unknown"])

    def test_threat_score_and_confidence_are_separate(self):
        result = self.analyze_demo("demo-invoice")
        self.assertNotEqual(result["threatScore"], result["evidenceConfidence"])

    def test_missing_headers_preserve_uncertainty(self):
        result = self.engine.analyze("From: person@example.org\nSubject: Hello\n\nNormal message")
        route = [item for item in result["evidence"] if item["evidence_type"] == "ROUTE_COVERAGE"]
        self.assertEqual(route[0]["status"], "UNCERTAINTY")
        self.assertIsNone(result["primaryObservedIp"])

    def test_attachment_is_hashed_but_not_executed(self):
        raw = """From: sender@example.org
Subject: Attachment
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary=x

--x
Content-Type: text/plain

Review this file.
--x
Content-Type: application/octet-stream
Content-Disposition: attachment; filename=invoice.js
Content-Transfer-Encoding: base64

YWxlcnQoMSk=
--x--
"""
        result = self.engine.analyze(raw)
        self.assertEqual(len(result["attachments"]), 1)
        self.assertTrue(result["attachments"][0]["dangerousExtension"])
        self.assertFalse(result["attachments"][0]["executed"])
        self.assertEqual(len(result["attachments"][0]["sha256"]), 64)


if __name__ == "__main__":
    unittest.main()
