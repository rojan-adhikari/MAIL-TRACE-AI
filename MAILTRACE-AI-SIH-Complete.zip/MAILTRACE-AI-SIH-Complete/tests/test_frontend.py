import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class FrontendDiscoverabilityTests(unittest.TestCase):
    def test_all_investigation_modules_are_visible_in_navigation(self):
        html = (ROOT / "web" / "index.html").read_text(encoding="utf-8")
        for label in (
            "Dashboard",
            "Investigate",
            "Gmail Live",
            "Cases",
            "Threat Graph",
            "Campaigns",
            "Threat Intelligence",
            "Reports",
            "Model Evaluation",
            "Settings",
        ):
            self.assertIn(label, html)

    def test_compact_menu_and_complete_demo_are_exposed(self):
        html = (ROOT / "web" / "index.html").read_text(encoding="utf-8")
        css = (ROOT / "web" / "features.css").read_text(encoding="utf-8")
        script = (ROOT / "web" / "app.js").read_text(encoding="utf-8")
        self.assertIn('id="mobile-menu"', html)
        self.assertIn("RUN COMPLETE SIH DEMO", html)
        self.assertIn("Gmail filters the message. MAILTRACE investigates the evidence.", html)
        self.assertIn(".sidebar.open", css)
        self.assertIn("SENDER + DEVICE", script)
        self.assertIn("IP + LOCATION", script)
        self.assertIn("RELAY PATH", script)
        self.assertIn("THREAT GRAPH", script)


if __name__ == "__main__":
    unittest.main()
