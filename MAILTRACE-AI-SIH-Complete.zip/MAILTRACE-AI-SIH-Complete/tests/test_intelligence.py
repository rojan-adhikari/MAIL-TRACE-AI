import unittest

from mailtrace.intelligence import IntelligenceService


class IntelligenceTests(unittest.TestCase):
    def test_private_and_demo_ips_are_not_live_enriched(self):
        service = IntelligenceService()
        with self.assertRaisesRegex(ValueError, "cannot be queried"):
            service.lookup_ip("192.168.1.10")
        with self.assertRaisesRegex(ValueError, "cannot be queried"):
            service.lookup_ip("203.0.113.77")

    def test_integration_status_never_fakes_keys(self):
        service = IntelligenceService()
        status = {item["name"]: item["status"] for item in service.status()}
        self.assertIn(status["VirusTotal"], {"CONFIGURED", "NOT CONFIGURED"})
        self.assertIn(status["AbuseIPDB"], {"CONFIGURED", "NOT CONFIGURED"})


if __name__ == "__main__":
    unittest.main()
