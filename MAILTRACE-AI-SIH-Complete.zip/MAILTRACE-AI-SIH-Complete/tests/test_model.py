import unittest
from pathlib import Path

from mailtrace.model import LightweightThreatModel


ROOT = Path(__file__).resolve().parents[1]


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model = LightweightThreatModel(ROOT / "data" / "dataset.json")

    def test_benchmark_is_runtime_and_split_aware(self):
        result = self.model.benchmark()
        self.assertTrue(result["evaluatedAtRuntime"])
        self.assertEqual(result["dataset"]["train"], 20)
        self.assertEqual(result["dataset"]["validation"], 4)
        self.assertEqual(result["dataset"]["test"], 6)
        self.assertEqual(result["transformer"]["status"], "NOT CONFIGURED")

    def test_safe_evasion_check_reports_stability(self):
        result = self.model.evasion_check("Urgently transfer to the revised beneficiary and keep this confidential.")
        self.assertTrue(result["safeSyntheticTest"])
        self.assertIn(result["detectionStability"], {"HIGH", "MEDIUM", "LOW"})
        self.assertEqual(len(result["modifiedScores"]), 4)


if __name__ == "__main__":
    unittest.main()
