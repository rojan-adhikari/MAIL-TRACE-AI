import json
import tempfile
import unittest
from pathlib import Path

from mailtrace.forensics import InvestigationEngine
from mailtrace.model import LightweightThreatModel
from mailtrace.report import generate_pdf
from mailtrace.storage import CaseStore


ROOT = Path(__file__).resolve().parents[1]


class StorageReportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = CaseStore(Path(self.temp.name) / "cases.db")
        self.engine = InvestigationEngine(LightweightThreatModel(ROOT / "data" / "dataset.json"))
        self.demos = {item["id"]: item for item in json.loads((ROOT / "data" / "demos.json").read_text())}

    def tearDown(self):
        self.temp.cleanup()

    def analyze(self, demo_id):
        demo = self.demos[demo_id]
        return self.engine.analyze(demo["raw"], demo["fixture"], True)

    def test_case_ledger_verifies_and_pdf_is_valid(self):
        case = self.store.create_case(self.analyze("demo-ceo-bec"), "Test Analyst", False)
        self.assertTrue(case["ledgerVerified"])
        self.assertEqual(len(case["ledger"]), len(case["analysis"]["evidence"]))
        pdf = generate_pdf(case)
        self.assertTrue(pdf.startswith(b"%PDF-1.4"))
        self.assertIn(b"MAILTRACE AI", pdf)
        self.assertGreater(len(pdf), 3000)

    def test_shared_asn_creates_campaign(self):
        first = self.store.create_case(self.analyze("demo-lookalike"), "Test Analyst", False)
        second = self.store.create_case(self.analyze("demo-credential"), "Test Analyst", False)
        first_updated = self.store.get_case(first["case_id"])
        self.assertIsNotNone(second["campaign_id"])
        self.assertEqual(first_updated["campaign_id"], second["campaign_id"])
        self.assertEqual(len(self.store.campaigns()), 1)

    def test_human_decision_and_note_are_stored(self):
        case = self.store.create_case(self.analyze("demo-invoice"), "Test Analyst", False)
        updated = self.store.add_note(case["case_id"], "Contact supplier through an independent channel.", "Test Analyst")
        self.assertEqual(len(updated["notes"]), 1)
        decided = self.store.decision(case["case_id"], "ESCALATE", "Test Analyst")
        self.assertEqual(decided["status"], "ESCALATED")
        self.assertEqual(decided["decisions"][0]["decision"], "ESCALATE")


if __name__ == "__main__":
    unittest.main()
