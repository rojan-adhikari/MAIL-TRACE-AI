const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const state = { demos: [], currentAnalysis: null, currentCase: null, currentSource: null, currentTab: "overview", cases: [], gmailOffset: 0, gmailAlertIds: new Set(), firstAlertLoad: true };

const PIPELINE = ["Parsing email", "Header forensics", "Authentication", "Domain analysis", "URL intelligence", "Behavioral analysis", "Infrastructure correlation", "Threat graph", "Evidence ledger", "Final assessment"];

function escapeText(value) {
  const node = document.createElement("span");
  node.textContent = String(value ?? "");
  return node.innerHTML;
}

function formatDate(value) {
  try { return new Date(value).toLocaleString(); } catch (_) { return String(value); }
}

function showToast(message, error = false) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.className = error ? "visible error" : "visible";
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => { toast.className = ""; }, 4300);
}

async function api(path, options = {}) {
  if (location.protocol === "file:") throw new Error("Start the Python service and open http://127.0.0.1:8788 — do not open index.html directly.");
  let response;
  try {
    response = await fetch(path, { ...options, headers: options.body ? { "Content-Type": "application/json" } : undefined });
  } catch (_) {
    throw new Error("MAILTRACE local service is not running. Start it and keep Terminal open.");
  }
  const type = response.headers.get("content-type") || "";
  const body = type.includes("application/json") ? await response.json() : await response.text();
  if (!response.ok) throw new Error(body.error || "Request failed safely.");
  return body;
}

function pageMeta(name) {
  const map = {
    dashboard: ["DASHBOARD", "Security Operations Overview"], investigate: ["INVESTIGATE", "Email Investigation Engine"],
    gmail: ["GMAIL LIVE", "Near Real-Time Mailbox Monitoring"], cases: ["CASES", "Investigation Case Management"],
    graph: ["THREAT GRAPH", "Infrastructure Relationship Analysis"], campaigns: ["CAMPAIGNS", "Campaign Correlation"],
    intelligence: ["THREAT INTELLIGENCE", "Authorized Infrastructure Enrichment"], reports: ["REPORTS", "Forensic Evidence Reports"],
    benchmark: ["MODEL EVALUATION", "Reproducible Runtime Benchmark"], settings: ["SETTINGS", "Privacy and Integrations"],
  };
  return map[name] || [name.toUpperCase(), "MAILTRACE AI"];
}

function setMobileNav(open) {
  $("#sidebar").classList.toggle("open", open);
  $("#nav-scrim").classList.toggle("open", open);
  document.body.classList.toggle("nav-open", open);
  $("#mobile-menu").setAttribute("aria-expanded", String(open));
}

async function showView(name) {
  setMobileNav(false);
  $$(".view").forEach((view) => view.classList.toggle("active", view.id === `view-${name}`));
  $$(".nav-item").forEach((item) => item.classList.toggle("active", item.dataset.view === name));
  const [crumb, title] = pageMeta(name); $("#breadcrumb").textContent = crumb; $("#page-title").textContent = title;
  if (name === "dashboard") await loadDashboard();
  if (name === "cases") await loadCases();
  if (name === "campaigns") await loadCampaigns();
  if (name === "reports") await loadReports();
  if (name === "graph") await loadGlobalGraph();
  if (name === "benchmark") await loadBenchmark();
  if (name === "settings") await loadIntegrations();
  if (name === "gmail") { await refreshGmailStatus(); await refreshGmailMessages(true); }
}

function severityTag(value) { return `<span class="severity ${escapeText(value)}">${escapeText(value)}</span>`; }

async function loadDemos() {
  const data = await api("/api/demos");
  state.demos = data.demos;
  $("#demo-select").insertAdjacentHTML("beforeend", data.demos.map((item) => `<option value="${escapeText(item.id)}">${escapeText(item.name)} — ${escapeText(item.severity)}</option>`).join(""));
}

async function loadDashboard() {
  try {
    const data = await api("/api/dashboard");
    $("#stat-active").textContent = data.activeCases; $("#stat-critical").textContent = data.criticalThreats;
    $("#stat-emails").textContent = data.emailsAnalyzed; $("#stat-campaigns").textContent = data.campaignsDetected;
    $("#nav-critical").textContent = data.criticalThreats;
    const maxScore = Math.max(...data.recent.map((item) => item.threat_score), 100);
    $("#activity-chart").innerHTML = data.recent.slice().reverse().map((item) => `<div class="activity-bar ${item.severity.toLowerCase()}"><i style="height:${Math.max(4, item.threat_score / maxScore * 100)}%" title="${escapeText(item.subject)} — ${item.threat_score}/100"></i><span>${escapeText(item.case_id.slice(-5))}</span></div>`).join("") || '<div class="empty-list">No cases yet.</div>';
    const categoryMax = Math.max(...data.categories.map((item) => item.value), 1);
    $("#category-chart").innerHTML = data.categories.map((item) => `<div class="bar-row"><div><span>${escapeText(item.name)}</span><b>${item.value}</b></div><i><b style="width:${item.value/categoryMax*100}%"></b></i></div>`).join("") || '<div class="empty-list">No classifications.</div>';
    $("#infrastructure-list").innerHTML = data.infrastructure.map((item, index) => `<div class="rank"><i>${String(index+1).padStart(2,"0")}</i><span>${escapeText(item.name)}</span><b>${item.value}</b></div>`).join("") || '<div class="empty-list">No enriched infrastructure.</div>';
    $("#recent-cases").innerHTML = data.recent.map((item) => `<div class="case-row"><b>${escapeText(item.case_id)}</b><span>${escapeText(item.subject)}</span><em>${escapeText(item.classification)}</em><strong>${item.threat_score}</strong>${severityTag(item.severity)}</div>`).join("");
  } catch (error) { showToast(error.message, true); }
}

function initializeProgress() {
  $("#progress-steps").innerHTML = PIPELINE.map((item, index) => `<div class="progress-step" data-step="${index}"><b>${String(index+1).padStart(2,"0")}</b>${escapeText(item)}</div>`).join("");
}

function delay(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

async function animatePipeline(promise) {
  $("#progress-status").textContent = "RUNNING";
  for (let index = 0; index < PIPELINE.length; index += 1) {
    const step = $(`.progress-step[data-step="${index}"]`);
    step.classList.add("active");
    await delay(85);
    step.classList.remove("active"); step.classList.add("done");
  }
  const result = await promise;
  $("#progress-status").textContent = "COMPLETE";
  return result;
}

function analysisPayload(saveCase = false) {
  return {
    demoId: $("#demo-select").value,
    raw: $("#raw-email").value,
    saveCase,
    privacyMode: $("#global-privacy").checked,
    analyst: $("#analyst-name").value || "Rozan Adhikari",
  };
}

async function runInvestigation({ autoSave = false } = {}) {
  if (!$("#demo-select").value && !$("#raw-email").value.trim()) { showToast("Select a safe demo or paste an email first.", true); return; }
  const button = $("#analyze-email"); button.disabled = true; button.textContent = "ANALYZING EVIDENCE…";
  initializeProgress(); state.currentSource = { demoId: $("#demo-select").value, raw: $("#raw-email").value, gmailUid: null };
  try {
    const result = await animatePipeline(api("/api/investigate", { method: "POST", body: JSON.stringify(analysisPayload(autoSave)) }));
    state.currentAnalysis = result.analysis; state.currentCase = result.case || null;
    renderVerdict(); renderResultTab(state.currentTab); $("#result-workspace").classList.remove("hidden");
    const destination = window.matchMedia("(max-width: 1100px)").matches ? $("#verdict-panel") : $("#result-workspace");
    destination.scrollIntoView({ behavior: "smooth", block: "start" });
    showToast(`${result.analysis.severity} assessment complete — ${result.analysis.threatScore}/100 threat score.`);
    if (result.case) { await loadDashboard(); }
  } catch (error) { $("#progress-status").textContent = "FAILED SAFELY"; showToast(error.message, true); }
  finally { button.disabled = false; button.innerHTML = 'START FORENSIC ANALYSIS <b>→</b>'; }
}

function renderVerdict() {
  const a = state.currentAnalysis;
  const geo = a.geolocation;
  $("#verdict-panel").innerHTML = `<div class="verdict-top"><div class="verdict-class">${severityTag(a.severity)}<h2>${escapeText(a.classification)}</h2><p>Assessment based on ${a.evidence.length} structured evidence items. ${a.synthetic ? "Synthetic demonstration — not a real incident." : "Local/live input."}</p></div><div class="score-pair"><div class="score threat"><strong>${a.threatScore}</strong><span>THREAT / 100</span></div><div class="score confidence"><strong>${a.evidenceConfidence}</strong><span>EVIDENCE CONFIDENCE</span></div></div></div><div class="verdict-metadata"><div><span>OBSERVED INFRASTRUCTURE</span><b>${escapeText(geo?.organization || a.primaryObservedIp?.ip || "Not available")}</b></div><div><span>PROBABLE REGION</span><b>${escapeText(geo ? `${geo.city}, ${geo.country}` : "Not enriched / unavailable")}</b></div><div><span>GEOLOCATION CONFIDENCE</span><b>${geo?.confidence || 0}%</b></div><div><span>RELATED CAMPAIGNS</span><b>${a.campaignCorrelation?.relatedCampaigns || 0}</b></div><div><span>GRAPH NODES</span><b>${a.graph.nodes.length}</b></div><div><span>ANALYSIS TIME</span><b>${a.performanceMs} ms</b></div></div><div class="known-unknown"><div class="known"><strong>WHAT WE KNOW</strong><ul>${a.known.slice(0,5).map((item) => `<li>✓ ${escapeText(item)}</li>`).join("") || "<li>No strong malicious fact observed.</li>"}</ul></div><div class="unknown"><strong>WHAT WE DO NOT KNOW</strong><ul>${a.unknown.slice(0,4).map((item) => `<li>! ${escapeText(item)}</li>`).join("")}</ul></div></div><div class="result-hint"><b>FULL FORENSIC OUTPUT IS READY</b><span>Open sender/device, evidence, relay, location and graph below.</span></div><div class="verdict-actions"><button class="primary" id="save-case-result">${state.currentCase ? "CASE SAVED" : "SAVE CASE"}</button><button class="secondary" id="export-current" ${state.currentCase ? "" : "disabled"}>EXPORT PDF REPORT</button><button class="secondary" data-result-tab="overview">SENDER + DEVICE</button><button class="secondary" data-result-tab="evidence">WHY THIS VERDICT?</button><button class="secondary" data-result-tab="route">RELAY PATH</button><button class="secondary" data-result-tab="map">IP + LOCATION</button><button class="secondary" data-result-tab="graph">THREAT GRAPH</button></div>`;
  $("#save-case-result").disabled = Boolean(state.currentCase);
  $("#save-case-result").addEventListener("click", saveCurrentCase);
  $("#export-current").addEventListener("click", () => state.currentCase && downloadReport(state.currentCase.case_id));
  $$("#verdict-panel [data-result-tab]").forEach((button) => button.addEventListener("click", () => jumpToResult(button.dataset.resultTab)));
}

function jumpToResult(tab) {
  state.currentTab = tab;
  setResultTab();
  $("#result-workspace").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function runQuickDemo() {
  await showView("investigate");
  $("#demo-select").value = "demo-ceo-bec";
  $("#raw-email").value = "Synthetic CEO impersonation BEC demonstration — fixture loaded locally.";
  await runInvestigation({ autoSave: true });
}

async function saveCurrentCase() {
  try {
    let result;
    if (state.currentSource?.gmailUid) {
      result = await api("/api/gmail/save-case", { method: "POST", body: JSON.stringify({ uid: Number(state.currentSource.gmailUid), analyst: $("#analyst-name").value, privacyMode: $("#global-privacy").checked }) });
    } else {
      const payload = { ...analysisPayload(true), demoId: state.currentSource?.demoId || "", raw: state.currentSource?.raw || "" };
      result = (await api("/api/investigate", { method: "POST", body: JSON.stringify(payload) })).case;
    }
    state.currentCase = result; state.currentAnalysis = result.analysis; renderVerdict(); renderResultTab(state.currentTab);
    showToast(`Case ${result.case_id} saved with a verified evidence ledger.`); await loadDashboard();
  } catch (error) { showToast(error.message, true); }
}

function setResultTab() {
  $$("#result-tabs button").forEach((button) => button.classList.toggle("active", button.dataset.tab === state.currentTab));
  renderResultTab(state.currentTab);
}

function dlRows(rows) { return `<dl class="detail-list">${rows.map(([key,value]) => `<div><dt>${escapeText(key)}</dt><dd>${escapeText(value)}</dd></div>`).join("")}</dl>`; }

function renderOverview(a) {
  const identity = [["From",a.senderDisplay],["Reply-To",a.replyTo],["Return-Path",a.returnPath],["Message-ID",a.messageId],["Date",a.date],["DKIM domains",a.dkimSigningDomains.join(", ") || "Not present"]];
  const auth = Object.entries(a.authentication).map(([key,value]) => [key,`${value.result} · ${value.confidence}%`]);
  const geo = a.geolocation;
  return `<div class="overview-grid"><section class="detail-card"><span>IDENTITY CONSISTENCY</span><h3>Sender headers</h3>${dlRows(identity)}</section><section class="detail-card"><span>EMAIL AUTHENTICATION</span><h3>Receiver-reported results</h3>${dlRows(auth)}</section><section class="detail-card"><span>DOMAIN INTELLIGENCE</span><h3>${escapeText(a.senderDomain)}</h3>${dlRows([["Closest protected domain",a.domainIntelligence.closestProtectedDomain.protectedDomain],["Brand similarity",`${a.domainIntelligence.closestProtectedDomain.overall || 0}%`],["TLD risk",a.domainIntelligence.tldRisk],["Punycode/IDN",a.domainIntelligence.idnPunycode],["Domain age",a.domainIntelligence.domainAge],["Registrar",a.domainIntelligence.registrar]])}</section><section class="detail-card"><span>INFRASTRUCTURE & DEVICE</span><h3>${escapeText(a.primaryObservedIp?.ip || "No public IP available")}</h3>${dlRows([["IP observation confidence",`${a.primaryObservedIp?.confidence || 0}%`],["Device/client clue",a.device.inferred],["Device confidence",`${a.device.confidence}%`],["Provider",geo?.organization || "Not enriched"],["Probable location",geo ? `${geo.city}, ${geo.region}, ${geo.country}` : "Unavailable"],["Attribution","NOT DETERMINED"]])}</section></div><div class="notice warning"><b>INVESTIGATIVE CONCLUSION</b><span>${escapeText(a.conclusion)}</span></div><div class="bar-list">${a.reliability.map((item) => `<div class="bar-row"><div><span>${escapeText(item.source)}</span><b>${item.confidence}%</b></div><i><b style="width:${item.confidence}%"></b></i></div>`).join("")}</div>`;
}

function renderEvidence(a) {
  return `<div class="evidence-list">${a.evidence.map((item) => `<article class="evidence-item"><div><h3>${escapeText(item.title)} · ${escapeText(item.status)}</h3><p>${escapeText(item.explanation)}</p><div class="evidence-meta">${escapeText(item.evidence_type)} · ${escapeText(item.source)} · ${escapeText(item.severity.toUpperCase())}</div></div><b>${item.confidence}%</b></article>`).join("")}</div>`;
}

function renderRoute(a) {
  if (!a.route.length) return '<div class="notice warning"><b>UNCERTAINTY</b><span>No Received headers were supplied. A route or source cannot be reconstructed.</span></div>';
  return `<div class="route-list">${a.route.map((hop) => `<article class="route-hop ${hop.trustLevel}"><span>HOP ${hop.hop}</span><div><h3>${escapeText(hop.fromHostname)} → ${escapeText(hop.byHostname)}</h3><p>${hop.ips.length ? hop.ips.map((item) => `${escapeText(item.ip)} [${escapeText(item.scope)}]`).join(", ") : "No verifiable IP"}</p><small>${escapeText(hop.timestamp)} · ${escapeText(hop.trustReason)}</small></div><em>${escapeText(hop.trustLevel)} ${hop.trustConfidence}%</em></article>`).join("")}</div>`;
}

function graphSvg(graph, inspectorId = null) {
  const nodes = graph.nodes.slice(0, 30);
  const width = 1000, height = 520, centerX = width/2, centerY = height/2;
  const positions = new Map();
  nodes.forEach((node,index) => {
    if (index === 0) positions.set(node.id,{x:centerX,y:centerY});
    else { const ring = index <= 10 ? 160 : 245; const slot = index <= 10 ? index-1 : index-11; const count = index <= 10 ? Math.min(10,nodes.length-1) : Math.max(1,nodes.length-11); const angle = slot/count*Math.PI*2-Math.PI/2; positions.set(node.id,{x:centerX+Math.cos(angle)*ring,y:centerY+Math.sin(angle)*ring}); }
  });
  const lines = graph.edges.filter((edge) => positions.has(edge.source) && positions.has(edge.target)).map((edge) => { const a=positions.get(edge.source),b=positions.get(edge.target); return `<g><line class="graph-edge" x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}"></line><text class="graph-label" x="${(a.x+b.x)/2}" y="${(a.y+b.y)/2-4}">${escapeText(edge.type)}</text></g>`; }).join("");
  const circles = nodes.map((node) => { const p=positions.get(node.id); const type=String(node.type).replaceAll(" ","-"); return `<g class="graph-node ${escapeText(type)}" data-node-id="${escapeText(node.id)}" data-node-type="${escapeText(node.type)}" data-node-label="${escapeText(node.label)}"><circle cx="${p.x}" cy="${p.y}" r="${node.type==='Email'?42:31}"></circle><text x="${p.x}" y="${p.y+3}">${escapeText(String(node.label).slice(0,22))}</text></g>`; }).join("");
  return `<svg class="graph-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="Threat infrastructure graph">${lines}${circles}</svg>`;
}

function renderMap(a) {
  const geo = a.geolocation;
  if (!geo || geo.latitude == null || geo.longitude == null) return '<div class="notice warning"><b>LOCATION UNAVAILABLE</b><span>No verified public infrastructure location is available. Exact sender location will not be guessed.</span></div>';
  const x=(Number(geo.longitude)+180)/360*900, y=(90-Number(geo.latitude))/180*430, radius=26+(100-Number(geo.confidence))*1.2;
  return `<div class="map-layout"><div class="world-map"><svg viewBox="0 0 900 430"><g>${[90,180,270,360,450,540,630,720,810].map(v=>`<line class="map-grid" x1="${v}" y1="0" x2="${v}" y2="430"/>`).join("")}${[72,144,216,288,360].map(v=>`<line class="map-grid" x1="0" y1="${v}" x2="900" y2="${v}"/>`).join("")}</g><path class="continent" d="M75 95 L170 55 255 88 238 155 188 177 148 238 100 202Z M265 255 L318 220 350 285 329 380 281 337Z M430 82 L540 55 606 94 570 142 495 154 462 121Z M515 165 L592 165 620 270 574 350 526 292Z M610 78 L777 65 838 130 786 193 690 172 649 122Z M758 295 L829 278 860 337 809 367 767 342Z"/><circle class="confidence-circle" cx="${x}" cy="${y}" r="${radius}"></circle><circle class="location-point" cx="${x}" cy="${y}" r="5"></circle></svg></div><div><section class="detail-card"><span>PROBABLE NETWORK INFRASTRUCTURE</span><h3>${escapeText(geo.city)}, ${escapeText(geo.country)}</h3>${dlRows([["Region",geo.region],["Coordinates",`${geo.latitude}, ${geo.longitude}`],["Confidence",`${geo.confidence}%`],["ASN",geo.asn],["Provider",geo.organization],["Cloud/VPS",geo.cloudProvider],["VPN",geo.vpn],["TOR",geo.tor],["Attribution",geo.attribution],["Source",geo.source]])}</section><div class="map-note">${escapeText(geo.disclaimer)} Confidence circle represents uncertainty; it is not an exact attacker pin.</div></div></div>`;
}

function renderIndicators(a) {
  return `<table class="ioc-table"><thead><tr><th>TYPE</th><th>VALUE</th><th>CONFIDENCE</th></tr></thead><tbody>${a.indicators.map((item) => `<tr><td>${escapeText(item.type)}</td><td>${escapeText(item.value)}</td><td>${item.confidence}%</td></tr>`).join("")}</tbody></table><div class="overview-grid" style="margin-top:10px"><section class="detail-card"><span>URL INTELLIGENCE</span><h3>${a.urls.length} extracted URLs</h3>${a.urls.map((item) => `<p>${escapeText(item.host)} · ${escapeText(item.flags.join(", ") || "No local flags")} · Reputation ${escapeText(item.reputation)}</p>`).join("") || "<p>No URLs extracted.</p>"}</section><section class="detail-card"><span>ATTACHMENTS</span><h3>${a.attachments.length} indicators</h3>${a.attachments.map((item) => `<p>${escapeText(item.filename)} · ${escapeText(item.sha256)} · Executed: NO</p>`).join("") || "<p>No attachment bytes or risky filename mentions.</p>"}</section></div>`;
}

function renderEvasion(a) {
  const e=a.evasionCheck; return `<div class="evasion-grid"><div class="evasion-card"><span>ORIGINAL SCORE</span><strong>${e.originalScore}</strong></div><div class="evasion-card"><span>MINIMUM MODIFIED</span><strong>${e.minimumScore}</strong></div><div class="evasion-card"><span>SCORE SPREAD</span><strong>${e.spread}</strong></div><div class="evasion-card"><span>DETECTION STABILITY</span><strong>${escapeText(e.detectionStability)}</strong></div></div><div class="notice synthetic" style="margin-top:10px"><b>SAFE SYNTHETIC TEST</b><span>Variations: ${escapeText(e.variations.join(", "))}. No real malicious email or live attack was generated.</span></div><div class="detail-card"><span>MODEL ARCHITECTURE</span><h3>${escapeText(a.ml.model)}</h3>${dlRows([["Baseline probability",`${a.ml.baselineProbability}%`],["Hybrid probability",`${a.ml.hybridProbability}%`],["LLM layer",a.ml.llm],["Modified scores",e.modifiedScores.join(", ")]])}</div>`;
}

function renderResultTab(tab) {
  const a = state.currentAnalysis; if (!a) return;
  const renderers = { overview:renderOverview, evidence:renderEvidence, route:renderRoute, graph:(value)=>`<div class="graph-canvas">${graphSvg(value.graph)}</div><div class="notice warning"><b>CORRELATION, NOT PROOF</b><span>Graph edges describe observed or inferred relationships and do not establish human attribution.</span></div>`, map:renderMap, indicators:renderIndicators, evasion:renderEvasion };
  $("#result-content").innerHTML = (renderers[tab] || renderOverview)(a);
}

async function loadCases() {
  try {
    const data=await api("/api/cases"); state.cases=data.cases;
    $("#cases-table").innerHTML=data.cases.map((item)=>`<tr><td>${escapeText(item.case_id)}</td><td>${escapeText(item.subject)}</td><td>${severityTag(item.severity)} ${escapeText(item.classification)}</td><td>${item.threat_score}/100</td><td>${escapeText(item.status)}</td><td>${escapeText(item.campaign_id||"—")}</td><td><button class="text-button" data-case-open="${escapeText(item.case_id)}">OPEN</button></td></tr>`).join("");
  } catch(error){showToast(error.message,true)}
}

async function openCase(caseId) {
  try {
    const c=await api(`/api/case?id=${encodeURIComponent(caseId)}`); const a=c.analysis;
    $("#case-detail").innerHTML=`<div class="case-detail-head"><div><span class="eyebrow">${escapeText(c.case_id)}</span><h2>${escapeText(a.subject)}</h2><p>${escapeText(c.status)} · ${escapeText(c.analyst)} · ${formatDate(c.created_at)} · Ledger ${c.ledgerVerified?"VERIFIED":"FAILED"}</p></div><div>${severityTag(a.severity)} <button class="secondary" data-report="${escapeText(c.case_id)}">EXPORT PDF</button></div></div><div class="verdict-metadata"><div><span>CLASSIFICATION</span><b>${escapeText(a.classification)}</b></div><div><span>THREAT / CONFIDENCE</span><b>${a.threatScore}/100 · ${a.evidenceConfidence}%</b></div><div><span>CAMPAIGN</span><b>${escapeText(c.campaign_id||"Not correlated")}</b></div><div><span>EVIDENCE LEDGER</span><b>${c.ledger.length} entries · ${c.ledgerVerified?"VALID":"INVALID"}</b></div></div><div class="decision-row">${["CONFIRM THREAT","MARK FALSE POSITIVE","ESCALATE","ADD TO CAMPAIGN","DISMISS","CLOSE CASE"].map((d)=>`<button class="secondary" data-decision="${d}" data-case="${escapeText(c.case_id)}">${d}</button>`).join("")}</div><div class="case-note"><input id="case-note-input" placeholder="Add analyst note"><button class="primary" data-add-note="${escapeText(c.case_id)}">ADD NOTE</button></div><div class="overview-grid" style="margin-top:10px"><section class="detail-card"><span>NOTES</span>${c.notes.map((n)=>`<p>${escapeText(n.note)}<br><small>${escapeText(n.analyst)} · ${formatDate(n.created_at)}</small></p>`).join("")||"<p>No notes.</p>"}</section><section class="detail-card"><span>ANALYST DECISIONS</span>${c.decisions.map((d)=>`<p>${escapeText(d.decision)} · ${escapeText(d.analyst)}</p>`).join("")||"<p>No decision recorded.</p>"}</section></div><div class="ledger-list">${c.ledger.map((item)=>`<div class="ledger-entry">${escapeText(item.evidence_id)} · evidence ${escapeText(item.evidence_hash)}<br>previous ${escapeText(item.previous_hash)}<br>chain ${escapeText(item.chain_hash)}</div>`).join("")}</div>`;
    $("#case-detail").classList.remove("hidden"); $("#case-detail").scrollIntoView({behavior:"smooth"});
  }catch(error){showToast(error.message,true)}
}

async function addCaseNote(caseId){try{await api("/api/case/note",{method:"POST",body:JSON.stringify({caseId,note:$("#case-note-input").value,analyst:$("#analyst-name").value})});showToast("Analyst note added.");await openCase(caseId)}catch(error){showToast(error.message,true)}}
async function caseDecision(caseId,decision){try{await api("/api/case/decision",{method:"POST",body:JSON.stringify({caseId,decision,analyst:$("#analyst-name").value})});showToast(`${decision} recorded.`);await openCase(caseId);await loadDashboard()}catch(error){showToast(error.message,true)}}
function downloadReport(caseId){window.open(`/api/report?caseId=${encodeURIComponent(caseId)}`,"_blank","noopener")}

async function loadCampaigns(){try{const {campaigns}=await api("/api/campaigns");$("#campaign-list").innerHTML=campaigns.map((item)=>`<article class="panel campaign-card"><span>${escapeText(item.campaign_id)}</span><h2>${escapeText(item.name)}</h2>${severityTag(item.risk)}<div class="campaign-stats"><div><b>${item.email_count}</b><small>EMAILS</small></div><div><b>${item.sender_count}</b><small>SENDERS</small></div><div><b>${item.cases.length}</b><small>CASES</small></div></div><p>First observed: ${formatDate(item.created_at)}<br>Latest: ${formatDate(item.updated_at)}</p>${item.cases.map((c)=>`<p><b>${escapeText(c.case_id)}</b> · ${escapeText(c.subject)}</p>`).join("")}</article>`).join("")||'<div class="empty-list">No correlated campaigns yet. Analyze cases sharing an IP, ASN, domain, URL or attachment hash.</div>'}catch(error){showToast(error.message,true)}}

async function loadGlobalGraph(){try{const {cases}=await api("/api/cases");state.cases=cases;$("#graph-case-select").innerHTML=cases.map((c)=>`<option value="${escapeText(c.case_id)}">${escapeText(c.case_id)} · ${escapeText(c.subject)}</option>`).join("");if(cases.length)await renderGlobalGraph(cases[0].case_id)}catch(error){showToast(error.message,true)}}
async function renderGlobalGraph(caseId){try{const c=await api(`/api/case?id=${encodeURIComponent(caseId)}`);$("#global-graph").innerHTML=graphSvg(c.analysis.graph,"graph-inspector");$("#graph-inspector").innerHTML='<span>NODE INSPECTOR</span><h3>Select a node</h3><p>Graph evidence is descriptive correlation, not automatic attribution.</p>'}catch(error){showToast(error.message,true)}}

function renderIntelResult(target,data){$(target).innerHTML=`<dl>${Object.entries(data).filter(([key])=>!["cached","disclaimer"].includes(key)).slice(0,18).map(([key,value])=>`<div><dt>${escapeText(key.replaceAll(/([A-Z])/g," $1"))}</dt><dd>${escapeText(Array.isArray(value)?value.join(", "):typeof value==="object"?JSON.stringify(value):value)}</dd></div>`).join("")}</dl><div class="notice warning" style="margin-top:10px"><b>LIMITATION</b><span>${escapeText(data.disclaimer||"Infrastructure intelligence does not prove human identity.")}</span></div>`}
async function lookupIp(event){event.preventDefault();try{const data=await api("/api/enrich/ip",{method:"POST",body:JSON.stringify({ip:$("#ip-input").value})});renderIntelResult("#ip-result",data)}catch(error){showToast(error.message,true)}}
async function lookupDomain(event){event.preventDefault();try{const data=await api("/api/enrich/domain",{method:"POST",body:JSON.stringify({domain:$("#domain-input").value})});renderIntelResult("#domain-result",data)}catch(error){showToast(error.message,true)}}

async function loadReports(){try{const {cases}=await api("/api/cases");$("#report-list").innerHTML=cases.map((c)=>`<article class="panel report-card"><span>${escapeText(c.case_id)} · ${c.synthetic?"SYNTHETIC":"LIVE/LOCAL"}</span><h2>${escapeText(c.subject)}</h2>${severityTag(c.severity)}<p>${escapeText(c.classification)}<br>Threat ${c.threat_score}/100 · Evidence confidence ${c.evidence_confidence}%<br>${formatDate(c.created_at)}</p><button class="primary" data-report="${escapeText(c.case_id)}">DOWNLOAD FORENSIC PDF</button></article>`).join("")}catch(error){showToast(error.message,true)}}

async function loadBenchmark(){try{const data=await api("/api/benchmark");const card=(title,item)=>`<article class="panel benchmark-card"><span>${escapeText(title)}</span><h2>${escapeText(item.model||item.status)}</h2>${item.status?`<div class="notice warning"><b>${escapeText(item.status)}</b><span>${escapeText(item.reason)}</span></div>`:`<div class="metric-grid">${[["Accuracy",item.accuracy],["Precision",item.precision],["Recall",item.recall],["F1",item.f1],["False positive",item.falsePositiveRate],["False negative",item.falseNegativeRate]].map(([k,v])=>`<div class="metric"><strong>${v}%</strong><small>${escapeText(k)}</small></div>`).join("")}</div>`}</article>`;$("#benchmark-content").innerHTML=`<div class="notice synthetic"><b>ACTUAL RUNTIME CALCULATION</b><span>${data.dataset.type}: ${data.dataset.train} train, ${data.dataset.validation} validation and ${data.dataset.test} test samples. Small synthetic metrics are not production accuracy claims.</span></div><div class="benchmark-grid">${card("BASELINE",data.baseline)}${card("TRANSFORMER",data.transformer)}${card("HYBRID EVIDENCE FUSION",data.hybrid)}</div><div class="evasion-grid" style="margin-top:10px"><div class="evasion-card"><span>ADVERSARIAL STABILITY</span><strong>${data.adversarialStability}%</strong></div><div class="evasion-card"><span>BASELINE TIME</span><strong>${data.baseline.averageAnalysisMs} ms</strong></div><div class="evasion-card"><span>HYBRID TIME</span><strong>${data.hybrid.averageAnalysisMs} ms</strong></div><div class="evasion-card"><span>TEST SAMPLES</span><strong>${data.dataset.test}</strong></div></div><div class="notice warning"><b>LIMITATION</b><span>${escapeText(data.limitations)}</span></div>`}catch(error){showToast(error.message,true)}}

async function loadIntegrations(){try{const {integrations}=await api("/api/integrations");$("#integration-list").innerHTML=integrations.map((item)=>`<div class="integration"><span>${escapeText(item.name)}<br><small>${escapeText(item.provider||"")}</small></span><b class="${item.status.includes("NOT")?"missing":"connected"}">${escapeText(item.status)}</b></div>`).join("")}catch(error){showToast(error.message,true)}}

async function connectGmail(event){event.preventDefault();const button=event.submitter;button.disabled=true;try{if("Notification"in window&&Notification.permission==="default")await Notification.requestPermission();const status=await api("/api/gmail/connect",{method:"POST",body:JSON.stringify({email:$("#gmail-email").value,appPassword:$("#gmail-password").value})});$("#gmail-password").value="";renderGmailStatus(status);state.gmailOffset=0;state.gmailAlertIds.clear();showToast("Gmail connected. Read-only analysis has started.")}catch(error){showToast(error.message,true)}finally{button.disabled=false}}
async function disconnectGmail(){try{renderGmailStatus(await api("/api/gmail/disconnect",{method:"POST",body:"{}"}));$("#gmail-messages").innerHTML='<div class="empty-list">Gmail disconnected. In-memory credentials and message analyses were cleared.</div>';showToast("Gmail disconnected safely.")}catch(error){showToast(error.message,true)}}
function renderGmailStatus(s){$("#gmail-pill").textContent=s.connected?(s.syncComplete?"MONITORING":"SYNCING"):"NOT CONNECTED";$("#gmail-pill").className=`status-pill ${s.connected?"online":"offline"}`;$("#gmail-status").textContent=s.status;$("#gmail-progress").style.width=`${s.syncProgress||0}%`;$("#gmail-sync-label").textContent=`${s.syncCount||0} of ${s.syncTotal||0} messages analyzed · read-only`;$("#nav-alerts").textContent=s.alertCount||0}
async function refreshGmailStatus(){try{renderGmailStatus(await api("/api/gmail/status"));await refreshGmailAlerts()}catch(_){}}
async function refreshGmailMessages(reset=false){if(reset)state.gmailOffset=0;try{const d=await api(`/api/gmail/messages?offset=${reset?0:state.gmailOffset}&limit=50`);if(reset)$("#gmail-messages").innerHTML="";if(!d.messages.length&&reset)$("#gmail-messages").innerHTML='<div class="empty-list">No synchronized messages yet.</div>';else $("#gmail-messages").insertAdjacentHTML("beforeend",d.messages.map((m)=>`<article class="panel gmail-message"><div class="gmail-score ${m.suspicious?"suspicious":""}">${m.threatScore}</div><div><h3>${escapeText(m.subject)}</h3><p>${escapeText(m.from)} · ${escapeText(m.classification)}</p><small>IP ${escapeText(m.observedIp)} · ${escapeText(m.device)} · ${m.routeHops} hops · ${m.evidenceConfidence}% confidence</small></div><div class="gmail-actions"><button class="secondary" data-gmail-investigate="${m.uid}">INVESTIGATE</button><button class="secondary" data-gmail-save="${m.uid}">SAVE CASE</button></div></article>`).join(""));state.gmailOffset=d.offset+d.messages.length;$("#gmail-more").classList.toggle("hidden",!d.hasMore)}catch(error){showToast(error.message,true)}}
async function investigateGmail(uid){try{const a=await api(`/api/gmail/message?uid=${encodeURIComponent(uid)}`);state.currentAnalysis=a;state.currentCase=null;state.currentSource={gmailUid:uid,demoId:"",raw:""};await showView("investigate");renderVerdict();renderResultTab("overview");$("#result-workspace").classList.remove("hidden");initializeProgress();$$(".progress-step").forEach(s=>s.classList.add("done"));$("#progress-status").textContent="COMPLETE"}catch(error){showToast(error.message,true)}}
async function saveGmailCase(uid){try{const c=await api("/api/gmail/save-case",{method:"POST",body:JSON.stringify({uid:Number(uid),analyst:$("#analyst-name").value,privacyMode:$("#global-privacy").checked})});showToast(`Case ${c.case_id} saved.`);await loadDashboard()}catch(error){showToast(error.message,true)}}
async function refreshGmailAlerts(){try{const {alerts}=await api("/api/gmail/alerts");const incoming=alerts.filter(a=>!state.gmailAlertIds.has(a.id)&&!a.historical);alerts.forEach(a=>state.gmailAlertIds.add(a.id));if(!state.firstAlertLoad&&incoming.length&&"Notification"in window&&Notification.permission==="granted")incoming.forEach(a=>new Notification(`MAILTRACE ${a.severity} alert`,{body:`${a.subject} · ${a.threatScore}/100`}));state.firstAlertLoad=false}catch(_){}}

$("#main-nav").addEventListener("click",(event)=>{const button=event.target.closest("[data-view]");if(button)showView(button.dataset.view)});
$("#mobile-menu").addEventListener("click",()=>setMobileNav(true));$("#sidebar-close").addEventListener("click",()=>setMobileNav(false));$("#nav-scrim").addEventListener("click",()=>setMobileNav(false));
document.addEventListener("click",(event)=>{const jump=event.target.closest("[data-jump]");if(jump)showView(jump.dataset.jump);const report=event.target.closest("[data-report]");if(report)downloadReport(report.dataset.report);const open=event.target.closest("[data-case-open]");if(open)openCase(open.dataset.caseOpen);const decision=event.target.closest("[data-decision]");if(decision)caseDecision(decision.dataset.case,decision.dataset.decision);const note=event.target.closest("[data-add-note]");if(note)addCaseNote(note.dataset.addNote);const gi=event.target.closest("[data-gmail-investigate]");if(gi)investigateGmail(gi.dataset.gmailInvestigate);const gs=event.target.closest("[data-gmail-save]");if(gs)saveGmailCase(gs.dataset.gmailSave)});
$("#result-tabs").addEventListener("click",(event)=>{const button=event.target.closest("[data-tab]");if(button){state.currentTab=button.dataset.tab;setResultTab()}});
$("#demo-select").addEventListener("change",()=>{const selected=state.demos.find(item=>item.id===$("#demo-select").value);if(selected){$("#raw-email").value=`Synthetic demonstration selected: ${selected.name}\n\nThe complete safe fixture will be loaded by the local backend.`;showToast("Synthetic demonstration selected. No real incident data is used.")}});
$("#analyze-email").addEventListener("click",()=>runInvestigation());$("#clear-email").addEventListener("click",()=>{$("#raw-email").value="";$("#demo-select").value=""});
$("#new-case").addEventListener("click",async()=>{$("#raw-email").value="";$("#demo-select").value="";state.currentAnalysis=null;state.currentCase=null;$("#result-workspace").classList.add("hidden");$("#verdict-panel").innerHTML='<div class="empty-verdict"><div class="radar-icon">◎</div><h2>New investigation</h2><p>Paste an email or select a safe synthetic scenario.</p></div>';await showView("investigate")});
$("#quick-demo").addEventListener("click",runQuickDemo);$("#dashboard-full-demo").addEventListener("click",runQuickDemo);$("#run-complete-demo").addEventListener("click",runQuickDemo);
$("#ip-form").addEventListener("submit",lookupIp);$("#domain-form").addEventListener("submit",lookupDomain);$("#rerun-benchmark").addEventListener("click",loadBenchmark);
$("#gmail-form").addEventListener("submit",connectGmail);$("#gmail-disconnect").addEventListener("click",disconnectGmail);$("#gmail-refresh").addEventListener("click",()=>refreshGmailMessages(true));$("#gmail-more").addEventListener("click",()=>refreshGmailMessages(false));
$("#graph-case-select").addEventListener("change",(event)=>renderGlobalGraph(event.target.value));$("#global-graph").addEventListener("click",(event)=>{const node=event.target.closest(".graph-node");if(node)$("#graph-inspector").innerHTML=`<span>NODE INSPECTOR</span><h3>${escapeText(node.dataset.nodeLabel)}</h3><p>Type: ${escapeText(node.dataset.nodeType)}<br>ID: ${escapeText(node.dataset.nodeId)}</p><div class="notice warning"><b>CONFIDENCE RULE</b><span>This node is an observed or derived indicator, not proof of human attribution.</span></div>`});
$("#save-settings").addEventListener("click",()=>{localStorage.setItem("mailtraceAnalyst",$("#analyst-name").value);localStorage.setItem("mailtraceRole",$("#analyst-role").value);showToast("Local analyst settings saved in this browser.")});
$("#analyst-name").value=localStorage.getItem("mailtraceAnalyst")||"Rozan Adhikari";$("#analyst-role").value=localStorage.getItem("mailtraceRole")||"SOC Analyst";

initializeProgress();
Promise.all([loadDemos(),loadDashboard(),loadIntegrations()]).catch((error)=>showToast(error.message,true));
setInterval(async()=>{await refreshGmailStatus();const status=await api("/api/gmail/status").catch(()=>null);if(status?.connected&&!status.syncComplete)await refreshGmailMessages(true)},8000);
